﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.AspNet.Core;
using Twilio.Rest.Api.V2010.Account;
using Twilio.TwiML;

namespace TwilioSms.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SmsController : TwilioController
    {

        [HttpPost("InboundSms")]
        public TwiMLResult InboundSms()
        {
            var messagingResponse = new MessagingResponse();

            var requestBody = Request.Form["Body"];

            if (requestBody == "Happy")
            {
                
               messagingResponse.Message("The inbound SMS. Message is Happy. From id : " + Request.Form["sid"]);
               
               return TwiML(messagingResponse);
            }

            messagingResponse.Message("Inbound SMS. Thanks.");

            return TwiML(messagingResponse);
        }

        [HttpPost("SendSms")]
        public object SendSms()
        {
            string accountSid = "AC46abc00c1b6df041a1ea1fd4af1021f0";
            string authToken = "9203f88e6bb07f167d63b7f66565aa96";

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                body: "Happy",
                from: new Twilio.Types.PhoneNumber("+14845099704"),
                to: new Twilio.Types.PhoneNumber("+17797720673")
            );

            return Ok(message);

        }


    }
}
