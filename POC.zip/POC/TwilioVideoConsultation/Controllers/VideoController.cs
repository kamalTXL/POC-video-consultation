﻿using Microsoft.AspNetCore.Mvc;
using SAAS_Video_Consultaion.Abstraction;
using System.Threading.Tasks;

namespace SAAS_Video_Consultaion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VideoController : ControllerBase
    {
        public readonly IVideoService _videoService;
        public VideoController(IVideoService videoService)
        {
            _videoService = videoService;
        }

        [HttpGet("rooms")]
        public async Task<IActionResult> GetRooms()
        {
            return new JsonResult(await _videoService.GetAllRoomsAsync());
        }
        [HttpPost("CreateRoom")]
        public IActionResult CreateRooms(string roomName)
        {
            return new JsonResult(_videoService.CreateRoom(roomName));
        }
        [HttpPost("UpdateRoom")]
        public IActionResult UpdateRoom(string roomSID)
        {
            return new JsonResult(_videoService.UpdateRoom(roomSID));
        }
        [HttpGet("GetRoomBySID")]
        public IActionResult GetRoomBySID(string roomSID)
        {
            return new JsonResult(_videoService.GetRoomBySID(roomSID));
        }
        [HttpGet("token")]
        public IActionResult GetToken(string roomSID, string identity)
        {
            return new JsonResult(new { token = _videoService.GetTwilioJwt(roomSID, identity) });
        }

        [HttpGet("addParticipantChat")]
        public IActionResult AddParticipantToConversationChat(string conversationSID, string identity)
        {
            return new JsonResult(_videoService.AddParticipantToConversationChat(conversationSID, identity));
        }

        [HttpGet]
        public async Task<IActionResult> GetAllConversation()
        {
            var conversationList = _videoService.GetAllConversation();
            return new JsonResult(await conversationList);
        }
        [HttpGet("turnToken")]
        public IActionResult GetTurnToken()
        {
            return new JsonResult(_videoService.GetTurnToken());
        }
    }
}
