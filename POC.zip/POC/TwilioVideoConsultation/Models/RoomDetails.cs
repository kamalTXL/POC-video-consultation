﻿namespace SAAS_Video_Consultaion.Models
{
    public class RoomDetails
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int ParticipantCount { get; set; }
        public int MaxParticipants { get; set; }
        public string RoomSid { get; set; }
    }
}
