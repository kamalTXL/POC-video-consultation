﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio.Rest.Conversations.V1.Conversation;

namespace SAAS_Video_Consultaion.Models
{
    public class ConversationDetails
    {
        public string FriendlyName { get; set; }
        public string ChatServiceId { get; set; }
        public string ChatId { get; set; }
        public List<ParticipantResource> Participants { get; set; }
    }
}
