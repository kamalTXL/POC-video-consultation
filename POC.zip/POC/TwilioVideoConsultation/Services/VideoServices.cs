﻿using Microsoft.IdentityModel.Tokens;
using SAAS_Video_Consultaion.Abstraction;
using SAAS_Video_Consultaion.Models;
using SAAS_Video_Consultaion.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Base;
using Twilio.Clients;
using Twilio.Jwt.AccessToken;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Rest.Chat.V1;
using Twilio.Rest.Conversations.V1;
using Twilio.Rest.Video.V1;
using Twilio.Rest.Video.V1.Room;
using ParticipantStatus = Twilio.Rest.Video.V1.Room.ParticipantResource.StatusEnum;

namespace SAAS_Video_Consultaion.Services
{
    public class VideoServices : IVideoService
    {
        readonly TwilioSetting _twilioSettings;
        readonly TwilioClient _client;

        public VideoServices(Microsoft.Extensions.Options.IOptions<TwilioSetting> twilioOptions)
        {
            _twilioSettings = twilioOptions?.Value ?? throw new ArgumentNullException(nameof(twilioOptions));
            TwilioClient.Init(_twilioSettings.ApiKey, _twilioSettings.ApiSecret);
        }

        public async Task<IEnumerable<RoomDetails>> GetAllRoomsAsync()
        {
            var rooms = await RoomResource.ReadAsync();
            var tasks = rooms.Select(room => GetRoomDetailsAsync(room, ParticipantResource.ReadAsync(room.Sid, ParticipantStatus.Connected)));
            return await Task.WhenAll(tasks);

            static async Task<RoomDetails> GetRoomDetailsAsync(RoomResource room, Task<ResourceSet<ParticipantResource>> participantTask)
            {
                var participants = await participantTask;
                return new RoomDetails
                {
                    Name = room.UniqueName,
                    MaxParticipants = room.MaxParticipants ?? 0,
                    RoomSid = room.Sid,
                    ParticipantCount = participants.ToList().Count,
                };
            }
        }
        public RoomResource CreateRoom(string roomName)
        {
            RoomResource room = RoomResource.Create(uniqueName: roomName, emptyRoomTimeout: 1, unusedRoomTimeout: 5, recordParticipantsOnConnect: true, maxParticipants: 10, maxParticipantDuration: 601);
            return room;
        }

        public RoomResource GetRoomBySID(string roomSID)
        {
            RoomResource room = RoomResource.Fetch(pathSid: roomSID);
            return room;
        }
        public RoomResource UpdateRoom(string roomSID)
        {
            RoomResource room = RoomResource.Update(pathSid: roomSID, status: RoomResource.RoomStatusEnum.Completed.ToString());
            return room;
        }
        public string GetTwilioJwt(string roomSID, string identity)
        {
            var services = Twilio.Rest.Conversations.V1.ServiceResource.Read();
            var requiredServiceId = services.Select(service => service.Sid).First();

            var Videorants = new VideoGrant();
            Videorants.Room = roomSID;
            var ChatGrants = new ChatGrant();
            ChatGrants.ServiceSid = requiredServiceId;

            var token = new Token(_twilioSettings.AccountSID,
                         _twilioSettings.ApiKey,
                         _twilioSettings.ApiSecret,
                         identity ?? Guid.NewGuid().ToString(),
                         nbf: DateTime.Now,
                         expiration: DateTime.Now.AddMinutes(10),
                         grants: new HashSet<IGrant> { Videorants, ChatGrants }).ToJwt();
            return token;
        }

        public string AddParticipantToConversationChat(string conversationSID, string identity)
        {
            try
            {
                var participant = Twilio.Rest.Conversations.V1.Conversation.ParticipantResource.Create(
                identity: identity,
                pathConversationSid: conversationSID);
                return participant.Sid;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public async Task<IEnumerable<ConversationDetails>> GetAllConversation()
        {
            var conversationList = await ConversationResource.ReadAsync();
            var requiredList = conversationList.Select(conversation => GetAllConversationById(conversation, Twilio.Rest.Conversations.V1.Conversation.ParticipantResource.ReadAsync(conversation.Sid)));
            return await Task.WhenAll(requiredList);
            static async Task<ConversationDetails> GetAllConversationById(ConversationResource conversation, Task<ResourceSet<Twilio.Rest.Conversations.V1.Conversation.ParticipantResource>> participantTask)
            {
                var participants = await participantTask;
                return new ConversationDetails
                {
                    FriendlyName = conversation.FriendlyName,
                    ChatServiceId = conversation.ChatServiceSid,
                    ChatId = conversation.Sid,
                    Participants = participants.ToList()
                };
            }
        }

        public TokenResource GetTurnToken()
        {
            var token = TokenResource.Create(_twilioSettings.AccountSID);
            return token;
        }
    }
}
