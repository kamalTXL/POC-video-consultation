﻿namespace SAAS_Video_Consultaion.Options
{
    public class TwilioSetting
    {
        public string AccountSID { get; set; }
        public string ApiSecret { get; set; }
        public string ApiKey { get; set; }
    }
}
