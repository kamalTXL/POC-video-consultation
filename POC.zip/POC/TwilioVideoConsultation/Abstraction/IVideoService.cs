﻿using SAAS_Video_Consultaion.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Rest.Video.V1;

namespace SAAS_Video_Consultaion.Abstraction
{
    public interface IVideoService
    {
        Task<IEnumerable<RoomDetails>> GetAllRoomsAsync();
        public RoomResource CreateRoom(string roomName);
        public string GetTwilioJwt(string roomSID, string identity);
        public RoomResource GetRoomBySID(string roomName);

        public RoomResource UpdateRoom(string roomSID);
        public string AddParticipantToConversationChat(string conversationSID, string identity);
        public Task<IEnumerable<ConversationDetails>> GetAllConversation();
        public TokenResource GetTurnToken();
    }
}
