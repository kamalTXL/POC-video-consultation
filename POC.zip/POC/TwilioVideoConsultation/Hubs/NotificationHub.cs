﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace SAAS_Video_Consultaion.Hubs
{
    public class NotificationHub : Hub
    {
        public async Task RoomsUpdated(bool isUpdated)
        {
            await Clients.Others.SendAsync("RoomsUpdated", isUpdated);
        }
    }
}
