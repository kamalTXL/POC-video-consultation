import {
  Component,
  ViewChild,
  ElementRef,
  Output,
  Input,
  EventEmitter,
  Renderer2,
  ChangeDetectorRef
} from '@angular/core';
import {
  Participant,
  RemoteTrack,
  RemoteAudioTrack,
  RemoteVideoTrack,
  RemoteParticipant,
  RemoteTrackPublication,
  VideoProcessor,
  VideoTrack,
  RemoteDataTrack
} from 'twilio-video';
import { VideoChatService } from '../services/videochat.service';

@Component({
  selector: 'app-participants',
  styleUrls: ['./participants.component.css'],
  templateUrl: './participants.component.html',
})
export class ParticipantsComponent {
  @ViewChild('list',{static:false}) listRef: ElementRef;
  @Output('participantsChanged') participantsChanged = new EventEmitter<boolean>();
  @Output() showParticipantsFullView = new EventEmitter<HTMLMediaElement>();
  @Output() sendMessage = new EventEmitter<string | ArrayBuffer>();
  @Output('leaveRoom') leaveRoom = new EventEmitter<boolean>();
  @Input('activeRoomName') activeRoomName: string;

  get participantCount() {
      return !!this.participants ? this.participants.size : 0;
  }

  get isAlone() {
      return this.participantCount === 0;
  }

  private participants: Map<Participant.SID, RemoteParticipant>;
  private dominantSpeaker: RemoteParticipant;
  private defaultAvatar: HTMLImageElement
  private allPaticipantsIds: string[] = []

  constructor(private readonly renderer: Renderer2, private readonly videoService: VideoChatService, private ref: ChangeDetectorRef) { }

  clear() {
      if (this.participants) {
          this.participants.clear();
      }
  }

  initialize(participants: Map<Participant.SID, RemoteParticipant>) {
      this.participants = participants;
      if (this.participants) {
          this.participants.forEach(participant => this.registerParticipantEvents(participant));
      }
  }

  add(participant: RemoteParticipant) {
      if (this.participants && participant) {
          this.participants.set(participant.sid, participant);
          this.registerParticipantEvents(participant);
      }
  }

  remove(participant: RemoteParticipant) {
      if (this.participants && this.participants.has(participant.sid)) {
          this.participants.delete(participant.sid);
      }
  }

  loudest(participant: RemoteParticipant) {
    console.log("dominent specker changed",participant.identity)
      this.dominantSpeaker = participant;
  }

  onLeaveRoom() {
      this.leaveRoom.emit(true);
  }

  private registerParticipantEvents(participant: RemoteParticipant) {
      if (participant) {
          participant.tracks.forEach(publication => this.subscribe(publication,participant));
          participant.on('trackPublished', publication => this.subscribe(publication,participant));
          participant.on('trackUnpublished',
              publication => {
                  if (publication && publication.track) {
                      this.detachRemoteTrack(publication.track, participant);
                  }
              });
          participant.on('networkQualityLevelChanged',(networkQualityLevel, networkQualityStats) => this.onNetworkQualityLevelChanged('remote',networkQualityLevel, networkQualityStats))
      }
  }

  private subscribe(publication: RemoteTrackPublication | any, participant) {
      if (publication && publication.on) {
          publication.on('subscribed',
              (track: RemoteTrack) => this.attachRemoteTrack(track, participant,'subscribe'));
          publication.on('unsubscribed',
              (track: RemoteTrack) => this.detachRemoteTrack(track, participant, 'unsubscribe'));
          publication.on('publishPriorityChanged',
              (track: RemoteTrack)=> this.onPublishPriorityChanged(track));

      }
  }
  private onPublishPriorityChanged(track) {
    console.log('publishPriorityChanged')
  }
  public onNetworkQualityLevelChanged(from,qualityLevel, qualityStats) {
    console.log('networkQualityLevelChanged',from,qualityLevel)
    console.log({
      1: '▃',
      2: '▃▄',
      3: '▃▄▅',
      4: '▃▄▅▆',
      5: '▃▄▅▆▇'
    }[qualityLevel] || '');
  }
  private attachRemoteTrack(track: RemoteTrack,participant: RemoteParticipant, fromType='publish') {
    track.on('switchedOff', () => {
        //You may update your UI accordingly
        // You can also determine whether a particular RemoteTrack is switched off.
        console.log(`The RemoteTrack ${track.name} was switched off ${participant.identity}`);
      });
    //track.setPriority('low')
      track.on('switchedOn', () => {
        //You may update your UI accordingly
        // You can also determine whether a particular RemoteTrack is switched off.
        console.log(`The RemoteTrack ${track.name} was switched on ${participant.identity}`);
      });
      //track.on('started',(track: RemoteTrack)=> console.log("enabled track",track))
      //track.on('switchedOn',(track: RemoteTrack)=> console.log("enabled track",track))
    //   if (track.kind == 'data') {
    //     track.on('message', data => {
    //       console.log('From Data track', data);
    //       this.videoService.sendUpdatedMessae(data)
    //       return;
    //     });
    //   }
      if (this.isAttachable(track)) {
          const element = track.attach(); 
          //element.controls = true;
          // if(this.defaultAvatar)
          //  this.renderer.removeChild(this.listRef.nativeElement,this.defaultAvatar)
          this.renderer.data.id = track.sid; //element.muted = true
          //this.renderer.setStyle(element, 'border', '3px red solid');
          this.renderer.setStyle(element, 'width', '45%');
          this.renderer.setStyle(element, 'margin-left', '2.5%');
          this.renderer.appendChild(this.listRef.nativeElement, element);
          element.addEventListener('click', () => this.sendDataTOFullView(element) )
          // if(track.kind == 'video') {
          //   if(this.allPaticipantsIds.includes(participant.sid)) {
          //       document.getElementById(participant.sid).remove();
          //   } else {
          //       this.allPaticipantsIds.push(participant.sid);
          //   }
          // }
          this.participantsChanged.emit(true);
      }
  }

  private detachRemoteTrack(track: RemoteTrack,participant: RemoteParticipant, fromType = 'publish') {
    console.log('Participent Disconnected',fromType) 
    //track.on('started',(track: RemoteTrack)=> console.log("disabled track",track))
      if (this.isDetachable(track)) {
          track.detach().forEach(el => el.remove());

        this.participantsChanged.emit(true);
  }
}

  private isAttachable(track: RemoteTrack): track is RemoteAudioTrack | RemoteVideoTrack {
      return !!track &&
          ((track as RemoteAudioTrack).attach !== undefined ||
          (track as RemoteVideoTrack).attach !== undefined);
  }

  private isDetachable(track: RemoteTrack): track is RemoteAudioTrack | RemoteVideoTrack {
      return !!track &&
          ((track as RemoteAudioTrack).detach !== undefined ||
          (track as RemoteVideoTrack).detach !== undefined);
  }
  private async sendDataTOFullView(element) {
    //console.log()
    //element.requestFullscreen()
    //element.requestPictureInPicture();
    // if (document.pictureInPictureEnabled) {
    //     await element.requestPictureInPicture();
    // }
    // else {
    //     await document.exitPictureInPicture();
        
    // }
    //element.pause()
    //element.muted = true
    this.showParticipantsFullView.emit(element);
  }

  addParticipantToTheList(element: Element) {
    //this.renderer.data.id = track.sid; //element.muted = true
    
    this.renderer.setStyle(element, 'border', '0');
    this.renderer.setStyle(element, 'width', '45%');
    this.renderer.setStyle(element, 'margin-left', '2.5%');
    this.renderer.appendChild(this.listRef.nativeElement, element);
  }
}
