import { Component, OnInit, OnDestroy, EventEmitter, Output, Input, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { NamedRoom, VideoChatService } from '../services/videochat.service';

@Component({
    selector: 'app-rooms',
    styleUrls: ['./rooms.component.css'],
    templateUrl: './rooms.component.html',
})
export class RoomsComponent implements OnInit, OnDestroy {
    @Output() roomChanged = new EventEmitter<NamedRoom>();
    @Input() activeRoomName: string;

    roomName: string;
    rooms: NamedRoom[];
    identity: string;
    selectedRoom: NamedRoom
    private subscription: Subscription;

    constructor(
        private readonly videoChatService: VideoChatService,private ref: ChangeDetectorRef) { }

    async ngOnInit() {
        this.videoChatService.$update.subscribe(x => console.log("Updateed Pop",x))
        //console.log(this.activeRoomName)
        await this.updateRooms();
        this.subscription =
            this.videoChatService
                .$roomsUpdated
                .pipe(tap(_ => this.updateRooms()))
                .subscribe();
    }

    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    onTryAddRoom() {
        if (this.roomName) {
            this.onAddRoom(this.roomName);
        }
    }

    async onAddRoom(roomName: string) {
        this.roomName = null;
        const room = await this.videoChatService.createRoom(roomName)
        this.updateRooms()
        this.roomChanged.emit(null);
    }

    onJoinRoom() {
        if(this.selectedRoom) {
            localStorage.setItem('userName',this.identity)
            this.roomChanged.emit(this.selectedRoom);
        }
    }

    async updateRooms() {
        this.rooms = (await this.videoChatService.getAllRooms()) as NamedRoom[];
        //console.log(this.rooms)
        this.ref.detectChanges();
    }
}
