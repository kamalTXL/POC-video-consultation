import { Injectable } from '@angular/core';
import { ReplaySubject, Observable } from 'rxjs';

export type Devices = MediaDeviceInfo[];
export type DeviceTypes = {
    audioInput: MediaDeviceInfo[],
    audioOutput: MediaDeviceInfo[],
    VideoInput: MediaDeviceInfo[]
}

@Injectable({
  providedIn: "root"
})
export class DeviceService {
    $devicesUpdated: Observable<Promise<Devices>>;

    private deviceBroadcast = new ReplaySubject<Promise<Devices>>();

    constructor() {
        if (navigator && navigator.mediaDevices) {
            navigator.mediaDevices.ondevicechange = (_: Event) => {
                this.deviceBroadcast.next(this.getDeviceOptions());
            }
        }

        this.$devicesUpdated = this.deviceBroadcast.asObservable();
        this.deviceBroadcast.next(this.getDeviceOptions());
    }

   /**
    * checking device has permission or not.
    * @returns {boolean} gets true if permission granted otherwise false
    */
    private async isGrantedMediaPermissions(): Promise<boolean> {
        console.log('Get permission')
        if (navigator && navigator.userAgent && navigator.userAgent.indexOf('Chrome') < 0) {
            return true; // Follows standard workflow for non-Chrome browsers.
        }
        if (navigator && navigator['permissions']) {
            try {
                const permissionName = "camera" as PermissionName;
                const result = await navigator.permissions.query({ name: permissionName })
                if (result) {
                    if (result.state === 'granted') {
                        return true;
                    } else {
                        const isGranted = await new Promise<boolean>(resolve => {
                            result.onchange = (_: Event) => {
                                const granted = _.target['state'] === 'granted';
                                if (granted) {
                                    resolve(true);
                                }
                            }
                        });

                        return isGranted;
                    }
                }
            } catch (e) {
                // This is only currently supported in Chrome.
                // https://stackoverflow.com/a/53155894/2410379
                return true;
            }
        }

        return false;
    }

    private async getDeviceOptions(): Promise<Devices> {
        const isGranted = await this.isGrantedMediaPermissions();
        if (navigator && navigator.mediaDevices && isGranted) {
            let devices = await this.tryGetDevices();
            if (devices.every(d => !d.label)) {
                devices = await this.tryGetDevices();
            }
            return devices.filter(d => !!d.label);
        }

        return null;
    }

    /**
     * Finding all and filtering only selected devices.
     * @returns All devices that support this system.
     */
    private async tryGetDevices(): Promise<Devices> {
        const mediaDevices = await navigator.mediaDevices.enumerateDevices();
        // const devices = ['audioinput', 'audiooutput', 'videoinput'].reduce((options, kind) => {
        //     return options[kind] = mediaDevices.filter(device => device.kind === kind);
        // }, [] as Devices);
        const devices = ['audioinput', 'audiooutput', 'videoinput'].reduce((options, kind) => {
            let device = mediaDevices.find(device => device.kind === kind);
            options.push(device)
            return options
        }, [] as Devices);
        console.log(devices)
        return mediaDevices;
    }

    public async getAllAvailableDevices() {
        const allDevices = await this.tryGetDevices();
        let mediaDevices: DeviceTypes = {
            audioInput: allDevices.filter(device => device.kind == "audioinput"),
            audioOutput: allDevices.filter(device => device.kind == "audiooutput"),
            VideoInput: allDevices.filter(device => device.kind == "videoinput")
        }
        return mediaDevices;
    }
}
