import { connect, ConnectOptions, LocalTrack, Room } from 'twilio-video';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler, HttpHeaders, HttpParams } from '@angular/common/http';
import { ReplaySubject , Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';

interface AuthToken {
    token: string;
}

export interface NamedRoom {
    id: string;
    name: string;
    maxParticipants?: number;
    participantCount: number;
    roomSid: string
}

export type Rooms = NamedRoom[];

@Injectable({
  providedIn: "root"
})
export class VideoChatService {
    $roomsUpdated: Observable<boolean>;

    private roomBroadcast = new ReplaySubject<boolean>();

    $update: Observable<boolean>;
    private selectedRoom:NamedRoom = null;
    private updatePopUp = new ReplaySubject<boolean>();

    $updateMessage: Observable<string | ArrayBuffer>;

    private updatedMessages = new ReplaySubject<string | ArrayBuffer>();

    token: string = ""
    $updateConversation: Observable<Room>;
    private joinedConversation = new ReplaySubject<Room>();

    $qualityTest: Observable<any>;
    private qualityTest = new ReplaySubject<any>();

    BASE_URL_TWILIO_STATUS = 'https://status.twilio.com/api/v2/components.json';
    BASE_URL_PATIENT = "https://patients-api.test.dctelemedplatform.com/api/v1/";
    BASE_URL_PROVIDER = "https://provider-api.test.dctelemedplatform.com/api/v1/";
    constructor(private readonly http: HttpClient) {
        this.$roomsUpdated = this.roomBroadcast.asObservable();
        this.$update = this.updatePopUp.asObservable();
        this.$updateMessage = this.updatedMessages.asObservable();
        this.$updateConversation = this.joinedConversation.asObservable();
        this.$qualityTest = this.qualityTest.asObservable();
    }

    public updatePopup() {
        this.updatePopUp.next(true);
    }
    public async getAuthToken(roomSID: string) {
        let identity = localStorage.getItem('userName');
        let params = new HttpParams().set('roomSID',roomSID).append("identity",identity);
        const auth =
            await this.http
                      .get<AuthToken>(`api/video/token`,{params})
                      .toPromise();
        return auth.token;
    }

    addParticipant(conversationId, identity): Observable<any> {
        let params = new HttpParams().append("conversationSID",conversationId).append("identity",identity);
        return this.http.get<string>(`api/video/addParticipantChat`,{params})
    }

    getAllConversation(): Observable<any> {
        return this.http.get<any>(`api/video`)
    }

    getTURNToken(): Observable<any> {
        return this.http.get<any>(`api/video/turnToken`)
    }

    getAllRooms() {
        return this.http
                   .get<Rooms>('api/video/rooms')
                   .toPromise();
    }
    createRoom(roomName: string) {
        let params = new HttpParams().set('roomName',roomName);
        return this.http
                   .post<any>(`api/video/CreateRoom`,null,{params})
                   .toPromise();
    }
    async downlaodMedia(link) {
        let headers = new HttpHeaders();
        // const token = await this.getAuthToken();
        // headers.append("Authorization","Basic "+token);
        // this.http.get<Rooms>(link,{headers})
        //            .toPromise();
    }
    getDownloadLink(roomId: string) {
        let params = new HttpParams().set('roomId', roomId);
        return this.http
                   .get<Rooms>(`api/video/downlaod`, {params})
                   .toPromise();
    }

    getAllTwilioStatus() {
        return this.http
                   .get<any>(this.BASE_URL_TWILIO_STATUS)
                   .toPromise();
    }

    async joinOrCreateRoom(name: string, tracks: LocalTrack[],roomSID: string, participantName) {
        let room: Room = null;
        let connectionOptions: ConnectOptions = {
            name,
            tracks,
            bandwidthProfile: {
                video: {
                    mode: 'presentation',  // default grid
                    trackSwitchOffMode: 'predicted',    // default predicted
                    dominantSpeakerPriority: 'standard', // default standard
                    //maxSubscriptionBitrate: 1,     // default predicted
                    clientTrackSwitchOffControl: 'auto', // default  auto
                    contentPreferencesMode: 'auto' // default auto
                }
            },
            dominantSpeaker: true,
            networkQuality: {
                local: 1,
                remote: 2
            }
            }
        try {
            this.token = await this.getAuthToken(roomSID);
            room =
                await connect(this.token, connectionOptions);
        } catch (error) {
            console.error(`Unable to connect to Room: ${error.message}`);
            alert("Connot connect room, To many participants")
        } finally {
            if (room) {
                console.log('Room',room.localParticipant.sid,room.sid)
                this.roomBroadcast.next(true);
                this.joinedConversation.next(room);
            }
        }

        return room;
    }

    nudge() {
        this.roomBroadcast.next(true);
    }

    onRunQualityTest() {
        this.qualityTest.next();
    }
    sendUpdatedMessae(message: string | ArrayBuffer) {
        this.updatedMessages.next(message);
    }
    
    setSelectedRoom(room) {
        this.selectedRoom = room;
    }
    getSelectedRoom() {
        return this.selectedRoom
    }

    getPatientByIdData(Patientid: string): Observable<any> {
        return this.http.get(`${this.BASE_URL_PATIENT}Patients/Patient/${Patientid}`)
        .pipe(map((response: any) => {
         return response;
       }));
    }

}
