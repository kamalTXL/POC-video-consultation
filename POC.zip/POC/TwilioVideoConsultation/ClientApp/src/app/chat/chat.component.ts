import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Client, Conversation, Message } from '@twilio/conversations';
import { VideoChatService } from '../services/videochat.service';
import * as $ from 'jquery';
import { Room } from 'twilio-video';
@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  @ViewChild('MessageInput', { static: false }) messageInput: ElementRef;
  profileURL = "../assets/default.png";
  identity: string = "";
  allMessages: Message[] = []
  selectedConversation: Conversation = null;
  conversationsClient: Client
  token = ""

  constructor(private readonly videoChatService: VideoChatService) { }

  ngOnInit() {
    $('#action_menu_btn').click(function () {
      $('.action_menu').toggle();
    });
    this.getToken();
  }

  ngDestroy() {
    if (this.conversationsClient) {
      localStorage.removeItem("userName")
      this.conversationsClient.shutdown()
    }
  }
  getToken() {
    this.videoChatService.$updateConversation.subscribe(room => {
      if (this.videoChatService.token) {
        this.token = this.videoChatService.token;
        this.initConversation(room);
        this.identity = localStorage.getItem('userName') || room.localParticipant.identity
        this.createConversation(room.name, this.identity)
      }
    })
  }

  initConversation = async (room:Room) => {
    window["conversationsClient"] = Client
    this.conversationsClient = new Client(this.token);

    this.conversationsClient.on("connectionStateChanged", (state) => {
      if (state == "connecting") {
        console.log("State connecting")
      }
      if (state == "connected") {
        console.log("State connected")
      }
      if (state == "disconnecting") {
        console.log("State disconnecting")
      }
      if (state == "disconnected") {
        console.log("State disconnected")
      }
      if (state == "denied") {
        console.log("State denied")
      }
    })

    this.conversationsClient.on("conversationAdded", (conversation) => {
      console.log("Conversation Added", conversation)
      if(room.name == conversation.friendlyName) {
        this.selectedConversation = conversation
      }
      //conversation.add("212124424")
    })
    // this.conversationsClient.onWithReplay
    this.conversationsClient.on("conversationJoined", (conversation) => {
      console.log("Conversation Joined", conversation)
    })

    this.conversationsClient.on("conversationUpdated", (conversation) => {
      console.log("conversation Updated", conversation)
      this.getAllMessages();
    })
    this.conversationsClient.on("conversationLeft", (conversationLeft) => {
      console.log("Conversation Left", conversationLeft)
      this.selectedConversation = null;
    })

    this.conversationsClient.on("participantJoined", (participant) => {
      console.log("Participant Joined", participant)
    })

    this.conversationsClient.on("participantLeft", (participant) => {
      console.log("Participant Left", participant)
    })
    this.conversationsClient.on("messageAdded", (message) => {
      console.log("New Message Added", message)
    })
  }

  sendMessageToConveration(message) {
    if (this.selectedConversation)
      this.selectedConversation.sendMessage(message)
    this.messageInput.nativeElement.value = null;
  }

  createConversation(conversationName, identity) {
    if (this.conversationsClient) {
      this.videoChatService.getAllConversation().subscribe(allConversation => {
        let exitedConversation = allConversation.find(conv => conv.friendlyName == conversationName)
        if (!exitedConversation) {
          this.createConversationWithParticipant(conversationName, identity)
        } else {
          this.videoChatService.addParticipant(exitedConversation.chatId, identity).subscribe(participant => {
            console.log(participant);
          })
        }
      })
    }
  }

  createConversationWithParticipant(conversationName, identity) {
    this.conversationsClient.createConversation({ friendlyName: conversationName }).then(conversation => {
      console.log(conversation)
      this.videoChatService.addParticipant(conversation.sid, identity).subscribe(participant => {
        console.log(participant);
      })
    })
  }
  getAllMessages() {
    if (this.selectedConversation) {
      this.selectedConversation.getMessages().then(res => {
        this.allMessages = res.items;
      },
        err => {
          alert("Participant not available in this conversation")
        })
    }
  }


}
