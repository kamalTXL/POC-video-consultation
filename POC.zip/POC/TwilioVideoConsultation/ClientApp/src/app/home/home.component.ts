import { Component, ViewChild, OnInit, ChangeDetectorRef } from '@angular/core';
import { createLocalAudioTrack, Room, LocalTrack, LocalVideoTrack, LocalAudioTrack, RemoteParticipant, LocalTrackPublication, createLocalVideoTrack, LocalDataTrack } from 'twilio-video';
import { RoomsComponent } from '../rooms/rooms.component';
import { CameraComponent } from '../camera/camera.component';
import { SettingsComponent } from '../settings/settings.component';
import { ParticipantsComponent } from '../participants/participants.component';
import { NamedRoom, VideoChatService } from '../services/videochat.service';
//import { HubConnection, HubConnectionBuilder, LogLevel } from '@microsoft/signalr';
import { VideoControlsComponent } from '../video-controls/video-controls.component';
import { HubConnection, HubConnectionBuilder, LogLevel } from '@microsoft/signalr';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-home',
    styleUrls: ['./home.component.css'],
    templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {
    @ViewChild('rooms', { static: false }) rooms: RoomsComponent;
    @ViewChild('camera', { static: false }) camera: CameraComponent;
    @ViewChild('settings', { static: false }) settings: SettingsComponent;
    @ViewChild('participants', { static: false }) participants: ParticipantsComponent;
    @ViewChild('videoControls', { static: false }) videoControls: VideoControlsComponent;
    isAudioEnabled = true;
    isVidoEnabled = true;
    activeRoom: Room;
    screenTrack: LocalVideoTrack;
    private notificationHub: HubConnection;
    isRoomEnalbed = true;
    messages = []
    isPreviewing: boolean = false;
    constructor(
        private readonly videoChatService: VideoChatService, private ref: ChangeDetectorRef, private route: ActivatedRoute) { }

    async ngOnInit() {
        this.videoChatService.$updateMessage.subscribe(res => {
            console.log(res);
            this.messages.push(res);
        })
        const builder =
            new HubConnectionBuilder()
                .configureLogging(LogLevel.Information)
                .withUrl(`${location.origin}/notificationHub`);

        this.notificationHub = builder.build();
        this.notificationHub.on('RoomsUpdated', async updated => {
            if (updated) {
                console.log("Roooms Updated method called")
                await this.rooms.updateRooms();
            }
        });
        await this.notificationHub.start();
        let name = this.route.snapshot.paramMap.get('name')
        if (name) {
            this.onRequestConsult(name);
        }
    }

    onRequestConsult(name) {
        console.log(name);
        localStorage.setItem("userName",name)
        this.isRoomEnalbed = false;
        if(this.rooms.rooms && this.rooms.rooms.length > 0 && this.rooms.rooms.filter(x => x.name == "DemoRoom").length > 0) {
            this.onRoomChanged(this.rooms.rooms.filter(x => x.name == "DemoRoom")[0], name);
        } else {
            this.videoChatService.getAllRooms().then(rooms => {
                if(rooms && rooms.length > 0 && rooms.filter(x => x.name == "DemoRoom").length > 0) {
                    this.onRoomChanged(rooms.filter(x => x.name == "DemoRoom")[0], name);
                } else {
                    this.videoChatService.createRoom("DemoRoom").then(room => {
                        console.log(room);
                        let rooms: NamedRoom = {
                            id: '',
                            name: room.uniqueName,
                            participantCount: room.maxParticipants,
                            roomSid: room.sid
                        }
                        this.onRoomChanged(rooms, name);
                    }, error => {
                        console.log(this.rooms.rooms)
                        console.log("Room Already Exists");
                        if (this.rooms.rooms && this.rooms.rooms.length > 0 && this.rooms.rooms.filter(x => x.name == "DemoRoom").length > 0) {
                            this.onRoomChanged(this.rooms.rooms.filter(x => x.name == "DemoRoom")[0], name);
                        } else {
                            this.isRoomEnalbed = true;
                        }
                    })
                }
            })
        }

    }

    updatedPopUp() {
        this.videoChatService.updatePopup();
    }
    async onSettingsChanged(deviceInfo?: MediaDeviceInfo) {
        if (deviceInfo.kind == 'audiooutput') {
            if (this.activeRoom) {
                this.activeRoom.localParticipant.audioTracks.forEach(publication => publication.unpublish())
                const tracks = await createLocalAudioTrack({ deviceId: deviceInfo.deviceId })
                this.activeRoom.localParticipant.publishTrack(tracks)
            }
            return;
        }
        await this.camera.initializePreview(deviceInfo.deviceId);
        if (this.settings.isPreviewing) {
            const track = await this.settings.showPreviewCamera();
            if (this.activeRoom) {
                const localParticipant = this.activeRoom.localParticipant;
                localParticipant.videoTracks.forEach(publication => publication.unpublish());
                await localParticipant.publishTrack(track);
            }
        }
    }

    async onLeaveRoom(_: boolean) {
        if (this.activeRoom) {
            this.activeRoom.disconnect();
            this.activeRoom = null;
        }
        const videoDevice = this.settings.hidePreviewCamera();
        await this.camera.initializePreview(videoDevice && videoDevice.deviceId);
        this.notificationHub.send('RoomsUpdated', true);
        this.rooms.updateRooms();
        this.participants.clear();
        let name = this.route.snapshot.paramMap.get('name')
        if(name) {
            this.isRoomEnalbed = true;
            window.close();
        }
    }

    async onRoomChanged(room: NamedRoom, participantName: string = null) {
        if (room && room.name) {
            if (this.activeRoom) {
                this.activeRoom.disconnect();
            }
            this.camera.finalizePreview();
            const tracks = await Promise.all([
                createLocalAudioTrack(),

                this.settings.showPreviewCamera()
            ]);
            let particpantname = participantName || this.rooms.identity
            this.activeRoom =
                await this.videoChatService
                    .joinOrCreateRoom(room.name, tracks, room.roomSid, particpantname);

            this.isRoomEnalbed = false;
            this.participants.initialize(this.activeRoom.participants);
            this.registerRoomEvents();
            this.ref.detectChanges();
            this.notificationHub.send('RoomsUpdated', true);
        } else {
            this.notificationHub.send('RoomsUpdated', true);
        }
    }

    onParticipantsChanged(_: boolean) {
        this.videoChatService.nudge();
    }

    private registerRoomEvents() {
        this.activeRoom
            .on('disconnected',
                (room: Room) => room.localParticipant.tracks.forEach(publication => this.detachLocalTrack(publication.track)))
            .on('participantConnected',
                (participant: RemoteParticipant) => this.participants.add(participant))
            .on('participantDisconnected',
                (participant: RemoteParticipant) => this.participants.remove(participant))
            .on('dominantSpeakerChanged',
                (dominantSpeaker: RemoteParticipant) => this.participants.loudest(dominantSpeaker));
        this.activeRoom.localParticipant.on('networkQualityLevelChanged', (networkQualityLevel, networkQualityStats) => this.participants.onNetworkQualityLevelChanged('local', networkQualityLevel, networkQualityStats))
    }

    private detachLocalTrack(track: LocalTrack) {
        if (this.isDetachable(track)) {
            track.detach().forEach(el => el.remove());
        }
    }

    private isDetachable(track: LocalTrack): track is LocalAudioTrack | LocalVideoTrack {
        return !!track
            && ((track as LocalAudioTrack).detach !== undefined
                || (track as LocalVideoTrack).detach !== undefined);
    }
    public disableAudio() {
        if (this.activeRoom) {
            this.activeRoom.localParticipant.audioTracks.forEach(publication => publication.track.disable())
            this.isAudioEnabled = false;
        }
    }
    public async enableAudio() {
        if (this.activeRoom) {
            //const tracks = await createLocalAudioTrack()
            //this.activeRoom.localParticipant.publishTrack(tracks)
            this.activeRoom.localParticipant.audioTracks.forEach(publication => publication.track.enable());
            this.isAudioEnabled = true;
        }
    }
    public async disableVideo() {
        if (this.activeRoom) {
            this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.disable());
            // const tracks = await createLocalVideoTrack()
            // this.activeRoom.localParticipant.publishTrack(tracks.stop());
            //this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.disable());
            const videoDevice = this.settings.hidePreviewCamera();
            this.isVidoEnabled = false;
            //this.activeRoom.localParticipant.tracks.forEach(publication => this.detachLocalTrack(publication.track))
        }
    }
    public async enableVideo() {
        if (this.activeRoom) {
            // const tracks = await createLocalVideoTrack()
            // this.activeRoom.localParticipant.publishTrack(tracks);
            this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.enable());
            this.settings.showPreviewCamera();
            this.isVidoEnabled = true;

        }
    }
    shareScreen() {
        if (!this.screenTrack && navigator) {
            if (!navigator.mediaDevices) return;
            // @ts-ignore
            navigator.mediaDevices.getDisplayMedia().then(stream => {
                this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.unpublish())
                const screenTrack = new LocalVideoTrack(stream.getTracks()[0]);
                this.screenTrack = screenTrack;
                this.activeRoom.localParticipant.publishTrack(screenTrack);
                //this.activeRoom.localParticipant.publishTrack(screenTrack);
                //screenTrack.mediaStreamTrack.onended = () => { shareScreenHandler() };
            }).catch(() => {
                alert('Could not share the screen.');
            });
        }
        else {
            this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.unpublish())
            // screenTrack.stop();
            // screenTrack = null;
        }
    }
    stopSharingScreen() {
        this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.unpublish())
        this.enableVideo();
    }

    onControlsSelected(control) {
        console.log(control)
        if (control == 'diabledVideo') this.settings.hidePreviewCamera();
        if (control == 'enabledVideo') this.settings.showPreviewCamera();
        if (control == 'LeaveRoom') this.onLeaveRoom(true);
    }
    onShowParticipantsFullView(element: HTMLMediaElement) {
        const divElement = document.getElementById('showParticepant');

        if (divElement.childElementCount > 0) {
            if (element.isEqualNode(divElement.firstElementChild)) return
            this.participants.addParticipantToTheList(divElement.firstElementChild)
            //divElement.removeChild(divElement.lastElementChild);
        }
        element.style.setProperty('width', '98%')
        element.style.setProperty('border', '3px red solid')
        //element.classList.add('myCameraClass');
        divElement.append(element)
    }
    sendMessageOnEnter(event) {
        if (event.key === "Enter") {
            this.sendMessage(event.target.value)
        }
    }
    sendMessage(message) {
        if (this.activeRoom) {
            this.activeRoom.localParticipant.dataTracks.forEach((publication) => publication.track.send(message));
            (<HTMLInputElement>document.getElementById("chatMessage")).value = ""
        }
    }
    onChangeMessage(message) {
        this.messages.push(message)
    }

    onChatIconClicked() {
        console.log("Chat Icon Is clicked")
        this.settings.hidePreviewOnChatCliced();
    }

    onShowPreviewCliced() {
        this.settings.showPreviewOnChat();
    }
}
