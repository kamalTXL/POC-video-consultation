import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallMediaconnectionComponent } from './pre-call-mediaconnection.component';

describe('PreCallMediaconnectionComponent', () => {
  let component: PreCallMediaconnectionComponent;
  let fixture: ComponentFixture<PreCallMediaconnectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallMediaconnectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallMediaconnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
