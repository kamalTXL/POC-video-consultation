import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MediaConnectionBitrateTest, testMediaConnectionBitrate } from '@twilio/rtc-diagnostics';
import { DeviceService } from 'src/app/services/device.service';
import { StorageService } from 'src/app/services/storage.service';
import { VideoChatService } from 'src/app/services/videochat.service';
import { PreflightTestReport } from 'twilio-video';

export enum QualityScore {
  Poor,
  Suboptimal,
  Good,
  Excellent,
}
const statusIcons = {
  [QualityScore.Excellent]: 'green',
  [QualityScore.Good]: 'green',
  [QualityScore.Suboptimal]: 'yellow',
  [QualityScore.Poor]: 'red'
};
const toolTipContent = {
  roundTripTime: `Round-trip time (RTT) is the time a packet of data takes to go from sender to receiver and back again. High RTT can cause the video to lag, freeze, or slow down. This is usually attributed to slow or overloaded networks.`,
  jitter: `Jitter is the fluctuation of latency over time. Due to network congestion, data can take longer to travel. High jitter typically results in short bursts of video freezing, slow video, and choppy audio.`,
  packetLoss: `Packet loss is caused when data fails to reach its destination. High packet loss results in video freezing, slow video, and choppy audio. Packet loss is usually caused by overloaded routers or high CPU load on the machine.`,
  bitrate: `Bitrate is the way we measure the speed of the upload and download transfers. If a sender uploads data too quickly and exceeds the transfer speed, the network gets overwhelmed and can cause issues for everyone. Symptoms of this can be frozen video, downscaled video, frame-rate drops, choppy audio, and potentially dropped connections.`,
};
@Component({
  selector: 'app-pre-call-mediaconnection',
  templateUrl: './pre-call-mediaconnection.component.html',
  styleUrls: ['./pre-call-mediaconnection.component.css']
})
export class PreCallMediaconnectionComponent implements OnInit {
  @Output() qualityTest = new EventEmitter<any>();
  qualityScore = "";
  totalQualityScore:number;
  qualityInfo: any[] = [];
  constructor(private store: StorageService) { }

  ngOnInit() {
    this.onLoadQuality();
  }

  onLoadQuality() {
    let bitrateReport = this.store.finalTestResults.bitrateTestResults.report;
    let preflightReport = this.store.finalTestResults.preflightTestReport.report
    let { latency, jitter, packetLoss, bitrate, totalQualityScore } = this.getQualityScore(preflightReport, bitrateReport);
    //console.log(getScore);
    this.totalQualityScore = totalQualityScore;
    this.qualityScore = totalQualityScore === QualityScore.Excellent ? 'excellent' : 'good';
    let quality = [
      {
        name: "RTT (ms) avg/max",
        status: `${latency.average} / ${latency.max} (${QualityScore[latency.qualityScore]})`,
        icon: statusIcons[latency.qualityScore],
        tooltip: toolTipContent.roundTripTime,
      },
      {
        name: "Jitter (s) avg/max",
        status: `${jitter.average} / ${jitter.max} (${QualityScore[jitter.qualityScore]})`,
        icon: statusIcons[jitter.qualityScore],
        tooltip: toolTipContent.jitter ,
      },
      {
        name: "Packet loss avg/max",
        status: `${packetLoss.average}% / ${packetLoss.max}% (${QualityScore[packetLoss.qualityScore]})`,
        icon: statusIcons[packetLoss.qualityScore],
        tooltip: toolTipContent.packetLoss ,
      },
      {
        name: "Bitrate (kbps) avg/max",
        status: `${bitrate.average} / ${bitrate.max} (${QualityScore[bitrate.qualityScore]})`,
        icon: statusIcons[bitrate.qualityScore],
        tooltip: toolTipContent.bitrate ,
      },
    ]
    this.qualityInfo.push(...quality)
  }

  getQualityScore(preflightTestReport: PreflightTestReport | null, bitrateTestReport: MediaConnectionBitrateTest.Report | null) {
    const maxBitrate = bitrateTestReport.values ? Math.max(...bitrateTestReport.values) : 0;
    const stats = preflightTestReport.stats;
    const latency = {
      average: this.formatNumber(stats!.rtt!.average),
      max: this.formatNumber(stats!.rtt!.max),
      qualityScore: this.getSingleQualityScore(stats!.rtt!.average, 100, 250, 400),
    };

    const jitter = {
      average: this.formatNumber(stats!.jitter!.average),
      max: this.formatNumber(stats!.jitter!.max),
      qualityScore: this.getSingleQualityScore(stats!.jitter!.average, 5, 10, 30),
    };

    const packetLoss = {
      average: this.formatNumber(stats!.packetLoss!.average),
      max: this.formatNumber(stats!.packetLoss!.max),
      qualityScore: this.getSingleQualityScore(stats!.packetLoss!.average, 1, 3, 8),
    };

    const bitrate = {
      average: this.formatNumber(bitrateTestReport.averageBitrate!),
      max: this.formatNumber(maxBitrate),
      qualityScore: this.getSingleQualityScore(bitrateTestReport.averageBitrate!, 1000, 500, 150, true),
    };

    const totalQualityScore = Math.min(
      latency.qualityScore,
      jitter.qualityScore,
      packetLoss.qualityScore,
      bitrate.qualityScore
    ) as QualityScore;

    return {
      latency,
      jitter,
      packetLoss,
      bitrate,
      totalQualityScore,
    };
  }

  formatNumber(val: number | undefined) {
    return val.toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }

  getSingleQualityScore(
    stat: number | undefined,
    goodThreshold: number,
    suboptimalThreshold: number,
    poorThreshold: number,
    descending: boolean = false
  ) {
    if (typeof stat === 'undefined') {
      // We ignore values that are missing
      return QualityScore.Excellent;
    }

    if (descending) {
      if (stat > goodThreshold) return QualityScore.Excellent;
      if (stat > suboptimalThreshold) return QualityScore.Good;
      if (stat > poorThreshold) return QualityScore.Suboptimal;
      return QualityScore.Poor;
    }

    if (stat >= poorThreshold) return QualityScore.Poor;
    if (stat >= suboptimalThreshold) return QualityScore.Suboptimal;
    if (stat >= goodThreshold) return QualityScore.Good;
    return QualityScore.Excellent;
  }

  onClickFinishUp() {
    this.qualityTest.emit(this.totalQualityScore)
  }
  onClickSkip() {
    this.qualityTest.emit(this.totalQualityScore)
  }
  onClickOk() {
    this.qualityTest.emit(this.totalQualityScore)
  }

}
