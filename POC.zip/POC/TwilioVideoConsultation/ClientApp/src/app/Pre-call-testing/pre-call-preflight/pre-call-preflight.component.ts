import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MediaConnectionBitrateTest, testMediaConnectionBitrate } from '@twilio/rtc-diagnostics';
import { StorageService } from 'src/app/services/storage.service';
import { VideoChatService } from 'src/app/services/videochat.service';
import { PreflightTestReport, runPreflight } from 'twilio-video';


export type TwilioAPIStatus = 'operational' | 'major_outage' | 'partial_outage' | 'degraded_performance';

export interface TwilioStatus {
  ['Group Rooms']?: TwilioAPIStatus;
  ['Go Rooms']?: TwilioAPIStatus;
  ['Peer-to-Peer Rooms']?: TwilioAPIStatus;
  ['Recordings']?: TwilioAPIStatus;
  ['Compositions']?: TwilioAPIStatus;
  ['Network Traversal Service']?: TwilioAPIStatus;
}
const serviceStatusObj = {
  operational: { status: 'Up', icon: 'green' },
  major_outage: { status: 'Major Outage', icon: 'red' },
  partial_outage: { status: 'Partial Outage', icon: 'yellow' },
  degraded_performance: { status: 'Degraded', icon: 'yellow' },
};

@Component({
  selector: 'app-pre-call-preflight',
  templateUrl: './pre-call-preflight.component.html',
  styleUrls: ['./pre-call-preflight.component.css']
})
export class PreCallPreflightComponent implements OnInit {
  @Output() preflightSucess = new EventEmitter<PreflightTestReport>();
  services:any[]= [{name:'Signaling Gateway',status:'Unreachable',icon:'red'},{name:'TURN Servers',status:'Unreachable',icon:'red'}]
  signalingGatewayReachable: boolean = false;
  turnServersReachable: boolean = false;
  preflightTestInProgress: boolean = false;
  bitrateTestInProgress: boolean = false;
  preflightTestFinished: boolean = false;
  preflightTestError = null;
  preflightTestReport: PreflightTestReport;
  connectionFailed: boolean =  this.preflightTestFinished && (this.preflightTestError !== null || !this.signalingGatewayReachable || !this.turnServersReachable);
  constructor(private appService: VideoChatService,private store: StorageService) { }

  ngOnInit() {
    let finalTestResults = this.store.finalTestResults;
    if(!(finalTestResults.preflightTestReport.report || finalTestResults.preflightTestReport.error)) {
      this.initializePreflight();
    }
    if(!finalTestResults.connectivityResults.twilioServices) {
      this.loadServices();
    } else {
      this.services = this.store.services;
    }
    if(!(finalTestResults.bitrateTestResults.report || finalTestResults.bitrateTestResults.error)) {
      this.initializeBitrateTest();
    }
  }

  loadServices() {
    this.appService.getAllTwilioStatus().then(response => {
      const ALLOWED_COMPONENTS = [
        'Group Rooms',
        //'Peer-to-Peer Rooms',
        'Compositions',
        'Recordings',
        'Network Traversal Service',
        //'Go Rooms',
      ];
      const statusObj = {};

      response.components.forEach(({ name, status }: { name: keyof TwilioStatus; status: TwilioAPIStatus }) => {
        if (ALLOWED_COMPONENTS.includes(name)) {
          statusObj[name] = status;
          const updatedStatus = serviceStatusObj[status]
          this.services.push({name,...updatedStatus})
        }
      });
      this.store.finalTestResults.connectivityResults.twilioServices = statusObj;
    })
  }
  async initializePreflight() {
    this.preflightTestInProgress = true;
    this.appService.getAuthToken("123456").then(token => {

      let preflightTest = runPreflight(token);
      
      preflightTest.on('progress', (progress) => {
        console.log('preflight progress:', progress);
        if (progress === 'dtlsConnected' || progress === 'peerConnectionConnected') {
          this.signalingGatewayReachable = true;
          this.store.finalTestResults.connectivityResults.signalingRegion = true;
          this.services = this.services.map(service => service.name == 'Signaling Gateway' ? {name: service.name,status: 'Reachable',icon:'green'}: service )
        }
        if (progress === 'mediaAcquired') {
          this.turnServersReachable = true;
          this.store.finalTestResults.connectivityResults.TURN = true;
          this.services = this.services.map(service => service.name == 'TURN Servers' ? {name: service.name,status: 'Reachable',icon:'green'}: service )
        }
      })
  
      preflightTest.on('failed', (error, report) => {
        console.log('Received partial report:', report);
        this.preflightTestInProgress = false
        this.preflightTestFinished = false;
        this.preflightTestReport = report;
        this.store.finalTestResults.preflightTestReport.error = error.message;
      });
  
      preflightTest.on('completed', (report) => {
        this.preflightTestInProgress = false
        this.preflightTestFinished = true;
        this.preflightTestReport = report;
        this.store.finalTestResults.preflightTestReport.report = report;
        console.log("Test completed in  milliseconds.",report);
      });
    }).catch(error => this.preflightTestInProgress = false)
  }

  initializeBitrateTest() {
    this.bitrateTestInProgress = true;
    this.appService.getTURNToken().subscribe(res => {
      const bitrateTest = testMediaConnectionBitrate({ iceServers: res.iceServers });

      bitrateTest.on(MediaConnectionBitrateTest.Events.Bitrate, (bitrate) => {
        console.log('bitrate', bitrate)
      });

      bitrateTest.on(MediaConnectionBitrateTest.Events.Error, (error) => {
        console.log('bitrate error', error)
        this.store.finalTestResults.bitrateTestResults.error = error;
        this.bitrateTestInProgress = false;

      });

      bitrateTest.on(MediaConnectionBitrateTest.Events.End, (report) => {
        console.log('bitrate end', report)
        const maxBitrate = report.values ? Math.max(...report.values) : 0;
        this.store.finalTestResults.bitrateTestResults.bitrate = maxBitrate;
        this.store.finalTestResults.bitrateTestResults.report = report;
        this.bitrateTestInProgress = false;
      });
      setTimeout(() => {
        bitrateTest.stop();
      }, 15000);
    },
    error => {
      console.log(error)
      this.bitrateTestInProgress = false;
    }
    )
  }

  onClickOk() {
    this.store.services = this.services;
    this.preflightSucess.emit(this.preflightTestReport)

  }

  downloadFinalTestResults() {
    let finalTestResults = this.store.finalTestResults;

    const link = document.createElement('a');
    link.download = 'test_results.json';
    link.href = URL.createObjectURL(
      new Blob([JSON.stringify(finalTestResults, null, 2)], {
        type: 'application/json',
      })
    );
    link.click();
  };


}
