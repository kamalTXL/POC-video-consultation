import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallPreflightComponent } from './pre-call-preflight.component';

describe('PreCallPreflightComponent', () => {
  let component: PreCallPreflightComponent;
  let fixture: ComponentFixture<PreCallPreflightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallPreflightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallPreflightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
