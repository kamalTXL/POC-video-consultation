import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { StorageService } from 'src/app/services/storage.service';
import { QualityScore } from '../pre-call-mediaconnection/pre-call-mediaconnection.component';

@Component({
  selector: 'app-pre-call-results',
  templateUrl: './pre-call-results.component.html',
  styleUrls: ['./pre-call-results.component.css']
})
export class PreCallResultsComponent implements OnInit {
  @Input() totalQualityScore: any;
  @Output() resultsTab = new EventEmitter<any>();
  testsPassed: boolean = true;
  qualityScore: string;
  constructor(private store: StorageService) { }

  ngOnInit() {
    this.loadResulst();
  }
  loadResulst() {
    console.log(this.totalQualityScore)
    this.testsPassed = this.totalQualityScore === QualityScore.Excellent || this.totalQualityScore === QualityScore.Good;
    this.qualityScore = QualityScore[this.totalQualityScore].toLocaleLowerCase();
  }
  onClickOk(selectedTab) {
    this.resultsTab.emit(selectedTab)
  }
  onRetest() {
    window.location.reload();
  }

  onDownloadReport() {
    const report = this.store.finalTestResults;
    report.connectivityResults.TURN = report.connectivityResults.TURN ? 'Reachable' : 'Unreachable';
    report.connectivityResults.signalingRegion = report.connectivityResults.signalingRegion ? 'Reachable' : 'Unreachable';
    console.log(report);
     const link = document.createElement('a');
    link.download = 'test_results.json';
    link.href = URL.createObjectURL(
      new Blob([JSON.stringify(report, null, 2)], {
        type: 'application/json',
      })
    );
    link.click();
  }

}
