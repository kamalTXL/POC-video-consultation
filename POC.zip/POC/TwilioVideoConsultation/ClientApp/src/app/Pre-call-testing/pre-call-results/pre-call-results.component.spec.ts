import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallResultsComponent } from './pre-call-results.component';

describe('PreCallResultsComponent', () => {
  let component: PreCallResultsComponent;
  let fixture: ComponentFixture<PreCallResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
