import { Component, OnInit } from '@angular/core';
import { AudioInputTest, AudioOutputTest, DiagnosticError, testAudioInputDevice, testAudioOutputDevice, WarningName } from '@twilio/rtc-diagnostics';

import { runPreflight } from 'twilio-video';
import { DeviceService, DeviceTypes } from '../../services/device.service';
import { VideoChatService } from '../../services/videochat.service';

@Component({
  selector: 'app-pre-call-testing',
  templateUrl: './pre-call-testing.component.html',
  styleUrls: ['./pre-call-testing.component.css']
})
export class PreCallTestingComponent implements OnInit {
  audioInputTest: AudioInputTest;
  audioOutputTest: AudioOutputTest;
  inputLevel = 0;
  outputLevel = 0;
  playbackURI = "";
  isAudioOutputTestRunning = false
  isAudioInputTestRunning = false
  isRecording = false
  audioInputDevices: MediaDeviceInfo[]
  audioOutputDevices: MediaDeviceInfo[]
  videoInputDevices: MediaDeviceInfo[]
  constructor(private appService: VideoChatService, private deviceService: DeviceService) { }

  ngOnInit() {
    this.getAllDevices();
    this.initializePreflight();
  }

  async initializePreflight() {
    let token = await this.appService.getAuthToken("123456");
    let preflightTest = runPreflight(token);

    preflightTest.on('progress', (progress) => {
      console.log('preflight progress:', progress);
    })

    preflightTest.on('failed', (error, report) => {
      console.log('Received partial report:', report);
    });

    preflightTest.on('completed', (report) => {
      console.log("Test completed in " + report.testTiming.duration + " milliseconds.");
      console.log(" It took " + report.networkTiming.connect.duration + " milliseconds to connect");
      console.log(" It took " + report.networkTiming.media.duration + " milliseconds to receive media");
    });
  }

  async getAllDevices() {
    let devicesList = await this.deviceService.getAllAvailableDevices();
    this.audioInputDevices = devicesList.audioInput;
    this.audioOutputDevices = devicesList.audioOutput;
    this.videoInputDevices = devicesList.VideoInput;

  }

  readAudio(options: AudioInputTest.Options) {
    if (this.audioInputTest) {
      this.audioInputTest.stop();
    }
    const duration = options.enableRecording ? 4000 : 20000;
    options = { duration, ...options };
    this.audioInputTest = testAudioInputDevice(options);
    this.isAudioInputTestRunning = true;
    if (options.enableRecording) {
      this.isRecording = true;
    }

    this.audioInputTest.on(AudioInputTest.Events.Volume, (value: number) => {
      this.inputLevel = (value * 100) / 200;
    });

    this.audioInputTest.on(AudioInputTest.Events.End, (report: AudioInputTest.Report) => {
      if (this.playbackURI && report.recordingUrl) {
        URL.revokeObjectURL(this.playbackURI);
      }

      if (report.recordingUrl) {
        this.playbackURI = report.recordingUrl;
      }

      this.isRecording = false;
      this.isAudioInputTestRunning = false

    });

    this.audioInputTest.on(AudioInputTest.Events.Error, (diagnosticError: DiagnosticError) => {
      console.log('error', diagnosticError);
    });
    this.audioInputTest.on(AudioInputTest.Events.Warning, (name: WarningName) => {
      console.log('warning', name);
    });
    this.audioInputTest.on(AudioInputTest.Events.WarningCleared, (name: WarningName) => {
      console.log('warning-cleared', name);
    });
  }

  playAudio(options: AudioOutputTest.Options) {
    console.log('AudioOutputTest running');

    options = { doLoop: false, ...options };
    this.audioOutputTest = testAudioOutputDevice(options);
    this.isAudioOutputTestRunning = true;

    this.audioOutputTest.on(AudioOutputTest.Events.Volume, (value: number) => {
      this.outputLevel = (value * 100) / 200;
    });

    this.audioOutputTest.on(AudioOutputTest.Events.End, (report: AudioOutputTest.Report) => {
      this.isAudioOutputTestRunning = false;
      this.outputLevel = 0;

      // const stdDev = getStandardDeviation(report.values);
      // if (stdDev === 0) {
      //   console.log('No audio detected');
      // }
      console.log('AudioOutputTest ended', report);
    });

    this.audioOutputTest.on(AudioOutputTest.Events.Error, (diagnosticError: DiagnosticError) => {
      console.log('error', diagnosticError);
    });
  }

  stopAudioTest() {
    if (this.audioInputTest) {
      this.audioInputTest.stop();
      this.inputLevel = 0;
    }
    if (this.audioOutputTest) {
      this.audioOutputTest.stop();
      this.outputLevel = 0;
    }
  }

  onRecordClick(deviceId) {
    this.readAudio({deviceId: "", enableRecording: true})
  }

  onplayClick() {
    this.playAudio({ deviceId: "", testURI: this.playbackURI})
  }
}
