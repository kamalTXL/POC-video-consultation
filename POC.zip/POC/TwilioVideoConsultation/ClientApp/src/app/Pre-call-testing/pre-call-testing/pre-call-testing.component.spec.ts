import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallTestingComponent } from './pre-call-testing.component';

describe('PreCallTestingComponent', () => {
  let component: PreCallTestingComponent;
  let fixture: ComponentFixture<PreCallTestingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallTestingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallTestingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
