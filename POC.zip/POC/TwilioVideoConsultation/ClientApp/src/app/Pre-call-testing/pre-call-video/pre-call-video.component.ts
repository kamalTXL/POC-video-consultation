import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { DiagnosticError, testVideoInputDevice, VideoInputTest } from '@twilio/rtc-diagnostics';
import { DeviceService } from 'src/app/services/device.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-pre-call-video',
  templateUrl: './pre-call-video.component.html',
  styleUrls: ['./pre-call-video.component.css']
})
export class PreCallVideoComponent implements OnInit {
  @ViewChild('videoTag', { static: true }) videoElementRef: ElementRef;
  @Output() videoSuccess = new EventEmitter<VideoInputTest.Report>();
  videoInputDevices: MediaDeviceInfo[]
  videoInputTest: VideoInputTest;
  videoTestError: DiagnosticError;
  videoTestReport: VideoInputTest.Report;
  constructor(private deviceService: DeviceService,private store: StorageService) { }

  ngOnInit() { 
    this.getAllDevices();
  }

  async getAllDevices() {
    let devicesList = await this.deviceService.getAllAvailableDevices();
    this.videoInputDevices = devicesList.VideoInput;
    (this.videoInputDevices.length > 0) && this.startVideoTest(this.videoInputDevices[0].deviceId);
  }
  startVideoTest(deviceId) {
    this.stopVideoTest();
    const test = testVideoInputDevice({ element: this.videoElementRef.nativeElement, deviceId });
    this.videoInputTest = test;
    test.on(VideoInputTest.Events.Error, (err) => {console.log(err); this.videoTestError = err;});
    test.on(VideoInputTest.Events.End, (report) => {
      console.log(report)
      this.videoTestReport = report;
      this.store.finalTestResults.videoTestResults = report;
    });
  }

  stopVideoTest() {
    if(this.videoInputTest) {
      this.videoInputTest.stop();
      this.videoInputTest = null;
    }
  }

  onClickOk() {
    this.videoSuccess.emit(this.videoTestReport);
  }

  onVideoDeviceChange(deviceId) {
    this.startVideoTest(deviceId);
  }
  onClickSkip() {
    this.videoSuccess.emit(null);
  }

}
