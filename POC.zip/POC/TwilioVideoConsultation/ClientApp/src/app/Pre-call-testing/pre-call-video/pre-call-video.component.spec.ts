import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallVideoComponent } from './pre-call-video.component';

describe('PreCallVideoComponent', () => {
  let component: PreCallVideoComponent;
  let fixture: ComponentFixture<PreCallVideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallVideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallVideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
