import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallHomeComponent } from './pre-call-home.component';

describe('PreCallHomeComponent', () => {
  let component: PreCallHomeComponent;
  let fixture: ComponentFixture<PreCallHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
