import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-call-home',
  templateUrl: './pre-call-home.component.html',
  styleUrls: ['./pre-call-home.component.css']
})
export class PreCallHomeComponent implements OnInit {
  currentTab: string = "start";
  totalQualityScore: any = 0;
  constructor() { }

  ngOnInit() {
  }

  onPreflightSuccess(preflightReport) {
    console.log(preflightReport)
    this.currentTab = "quality"
  }
  onBrowserSuccess(event) {
    console.log(event)
    this.currentTab = "connectivity"
  }

  onVideoSuccess(event) {
    this.currentTab = 'audio'
  }
  onAudioChange() {
    this.currentTab = 'browser'
  }
  onQualityTest(event) {
    this.totalQualityScore = event;
    this.currentTab = "result"
  }
  onResultTest(selectedTab) {
    this.currentTab = selectedTab;
  }
  onGetstarted() {
    this.currentTab = "video"
  }

}
