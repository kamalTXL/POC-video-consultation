import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { AudioInputTest, AudioOutputTest, DiagnosticError, testAudioInputDevice, testAudioOutputDevice, WarningName } from '@twilio/rtc-diagnostics';
import { DeviceService } from 'src/app/services/device.service';
import { StorageService } from 'src/app/services/storage.service';
import { VideoChatService } from 'src/app/services/videochat.service';

@Component({
  selector: 'app-pre-call-audio',
  templateUrl: './pre-call-audio.component.html',
  styleUrls: ['./pre-call-audio.component.css']
})
export class PreCallAudioComponent implements OnInit {
  @ViewChild('prograssBar', { static: false }) prograssBar: HTMLDivElement;
  @Output() audio = new EventEmitter<any>();
  audioInputTest: AudioInputTest;
  audioOutputTest: AudioOutputTest;
  audioInputDevices: MediaDeviceInfo[]
  audioOutputDevices: MediaDeviceInfo[]
  selectedInputAudioDeviceId: string;
  selectedOutputAudioDeviceId: string;
  inputLevel = 0;
  outputLevel = 0;
  playbackURI = "";
  isAudioOutputTestRunning = false
  isAudioInputTestRunning = false
  isRecording = false
  constructor(private appService: VideoChatService, private deviceService: DeviceService,private store: StorageService) { }

  ngOnInit() {
    this.getAllDevices();
  }

  async getAllDevices() {
    let devicesList = await this.deviceService.getAllAvailableDevices();
    this.audioInputDevices = devicesList.audioInput;
    this.audioOutputDevices = devicesList.audioOutput;
  }

  readAudio(options: AudioInputTest.Options) {
    if (this.audioInputTest) {
      this.audioInputTest.stop();
    }
    const duration = options.enableRecording ? 4000 : 20000;
    options = { duration, ...options };
    this.audioInputTest = testAudioInputDevice(options);
    this.isAudioInputTestRunning = true;
    if (options.enableRecording) {
      this.isRecording = true;
    }

    this.audioInputTest.on(AudioInputTest.Events.Volume, (value: number) => {
      this.inputLevel = (value * 100) / 200;
    });

    this.audioInputTest.on(AudioInputTest.Events.End, (report: AudioInputTest.Report) => {
      if (this.playbackURI && report.recordingUrl) {
        URL.revokeObjectURL(this.playbackURI);
      }

      if (report.recordingUrl) {
        this.playbackURI = report.recordingUrl;
      }

      this.isRecording = false;
      this.isAudioInputTestRunning = false
      this.store.finalTestResults.audioTestResults.inputTest = report;

    });

    this.audioInputTest.on(AudioInputTest.Events.Error, (diagnosticError: DiagnosticError) => {
      console.log('error', diagnosticError);
    });
    this.audioInputTest.on(AudioInputTest.Events.Warning, (name: WarningName) => {
      console.log('warning', name);
    });
    this.audioInputTest.on(AudioInputTest.Events.WarningCleared, (name: WarningName) => {
      console.log('warning-cleared', name);
    });
  }

  playAudio(options: AudioOutputTest.Options) {
    console.log('AudioOutputTest running');

    options = { doLoop: false, ...options };
    this.audioOutputTest = testAudioOutputDevice(options);
    this.isAudioOutputTestRunning = true;

    this.audioOutputTest.on(AudioOutputTest.Events.Volume, (value: number) => {
      this.outputLevel = (value * 100) / 200;
    });

    this.audioOutputTest.on(AudioOutputTest.Events.End, (report: AudioOutputTest.Report) => {
      this.isAudioOutputTestRunning = false;
      this.outputLevel = 0;
      this.store.finalTestResults.audioTestResults.outputTest = report;
      // const stdDev = getStandardDeviation(report.values);
      // if (stdDev === 0) {
      //   console.log('No audio detected');
      // }
      console.log('AudioOutputTest ended', report);
    });

    this.audioOutputTest.on(AudioOutputTest.Events.Error, (diagnosticError: DiagnosticError) => {
      console.log('error', diagnosticError);
    });
  }

  stopAudioTest() {
    if (this.audioInputTest) {
      this.audioInputTest.stop();
      this.inputLevel = 0;
    }
    if (this.audioOutputTest) {
      this.audioOutputTest.stop();
      this.outputLevel = 0;
    }
  }

  onRecordClick() {
    this.readAudio({deviceId: this.selectedInputAudioDeviceId, enableRecording: true})
  }

  onplayClick() {
    this.playAudio({ deviceId: this.selectedOutputAudioDeviceId, testURI: this.playbackURI})
  }
  onClickOk() {
    this.audio.emit();
  }
  onClickSkip() {
    this.audio.emit();
  }
}
