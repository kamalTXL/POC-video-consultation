import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallAudioComponent } from './pre-call-audio.component';

describe('PreCallAudioComponent', () => {
  let component: PreCallAudioComponent;
  let fixture: ComponentFixture<PreCallAudioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallAudioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallAudioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
