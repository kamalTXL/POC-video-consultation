import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { StorageService } from 'src/app/services/storage.service';
import { isSupported } from 'twilio-video';
import UAParser from 'ua-parser-js';
@Component({
  selector: 'app-pre-call-browser-spport',
  templateUrl: './pre-call-browser-spport.component.html',
  styleUrls: ['./pre-call-browser-spport.component.css']
})
export class PreCallBrowserSpportComponent implements OnInit {
  @Output() browserSupport = new EventEmitter<any>();
  isBrowserSupported: boolean = false;
  userAgentInfo: UAParser.IResult;
  userAgentParser: UAParser = new UAParser();
  browser: any;
  operatingSystem: any;
  appURL = window.location.href;
  constructor(private store: StorageService) { }

  ngOnInit() {
    this.isBrowserSupported = isSupported;
    //userAgentParser = new UAParser();
    this.userAgentInfo = this.userAgentParser.getResult();
    this.store.finalTestResults.browserInformation = this.userAgentInfo;
    this.browser = this.userAgentInfo.browser;
    this.operatingSystem = this.userAgentInfo.os;
  }

  onClickOk() {
    this.browserSupport.emit();
  }

  copyAppLinkToClipBoard() {
    navigator.clipboard.writeText(this.appURL);
  };
}
