import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCallBrowserSpportComponent } from './pre-call-browser-spport.component';

describe('PreCallBrowserSpportComponent', () => {
  let component: PreCallBrowserSpportComponent;
  let fixture: ComponentFixture<PreCallBrowserSpportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreCallBrowserSpportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreCallBrowserSpportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
