import { Component, EventEmitter, Input, OnInit, Output, Renderer2 } from '@angular/core';
import { createLocalAudioTrack, createLocalVideoTrack, LocalVideoTrack, Room, TrackPublication } from 'twilio-video';
import { VideoChatService } from '../services/videochat.service';
import { SettingsComponent } from '../settings/settings.component';

@Component({
  selector: 'app-video-controls',
  templateUrl: './video-controls.component.html',
  styleUrls: ['./video-controls.component.css']
})
export class VideoControlsComponent implements OnInit {
  @Input() activeRoom: Room;
  isVidoEnabled: boolean = true
  isAudioEnabled: boolean = true
  shareScreen: boolean = true
  screenTrack: LocalVideoTrack;
  @Output() onControlsSelected = new EventEmitter<string>();
  //settings: SettingsComponent;

  constructor(private videoService: VideoChatService, private readonly renderer: Renderer2) { }

  ngOnInit() {
  }
  disableVideo() {
    if (this.activeRoom) {
      this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.stop());
      //this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.disable());
      //const videoDevice = this.settings.hidePreviewCamera();
      //this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.disable());
      this.isVidoEnabled = false;
      this.onControlsSelected.emit('diabledVideo');

      // let element = new Image() //document.createElement<>('image');
      // element.src = '../../assets/profile.jpg'
      // element.alt = "Krishna"//participant.identity;
      // element.id = 'fejfefefefefe'
      // element.innerHTML = 'fejfefefefefe'
      // element.classList.add('emptyParticipants')
      // element.classList.add('card')
      //document.body.appendChild(element)
      //this.renderer.appendChild(this.listRef.nativeElement, element);
      //this.activeRoom.localParticipant.tracks.forEach(publication => this.detachLocalTrack(publication.track))
    }
  }
  disableAudio() {
    if (this.activeRoom) {
      this.activeRoom.localParticipant.audioTracks.forEach(publication => publication.unpublish())
      //this.activeRoom.localParticipant.audioTracks.forEach(publication => publication.track.disable())
      this.isAudioEnabled = false;



    }
  }
  async enableVideo() {
    if (this.activeRoom) {
      //const tracks = await createLocalVideoTrack()
      //this.settings.showPreviewCamera();
      // this.activeRoom.localParticipant.publishTrack(tracks);
      this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.restart());
      this.isVidoEnabled = true;
      //this.renderer.appendChild(this.listRef.nativeElement, element);
      this.onControlsSelected.emit('enabledVideo');
    }
  }
  async enableAudio() {
    if (this.activeRoom) {
      const tracks = await createLocalAudioTrack()
      this.activeRoom.localParticipant.publishTrack(tracks)
      //this.activeRoom.localParticipant.audioTracks.forEach(publication => publication.track.enable());
      this.isAudioEnabled = true;
    }
  }
  shareScreenPublish() {
    if (!this.screenTrack && navigator) {
      if (!navigator.mediaDevices) return;
      // @ts-ignore
      navigator.mediaDevices.getDisplayMedia().then(stream => {
        this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.unpublish())
        const screenTrack = new LocalVideoTrack(stream.getTracks()[0]);
        this.screenTrack = screenTrack;
        screenTrack.mediaStreamTrack
        this.activeRoom.localParticipant.publishTrack(screenTrack);
        screenTrack.mediaStreamTrack.onended = () => { this.stopShareScreen() };
      }).catch(() => {
        alert('Could not share the screen.');
      });
    }
    else {
      this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.unpublish())
      // screenTrack.stop();
      // screenTrack = null;
    }
    this.shareScreen = false
  }
  async stopShareScreen() {
    if (this.activeRoom) {
      this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.unpublish())
      const tracks = await createLocalVideoTrack()
      //this.settings.showPreviewCamera();
      this.activeRoom.localParticipant.publishTrack(tracks);
      //this.activeRoom.localParticipant.videoTracks.forEach(publication => publication.track.restart());
      this.isVidoEnabled = true;
      this.shareScreen = true
      //this.renderer.appendChild(this.listRef.nativeElement, element);
      this.onControlsSelected.emit('enabledVideo');
    }
  }
  leaveRoom() {
    this.isVidoEnabled = true
    this.isAudioEnabled = true
    this.shareScreen = true
    this.onControlsSelected.emit('LeaveRoom')
  }
  async downloadRecordVideo() {
    if (this.activeRoom) {
      const roomSID = this.activeRoom.sid
      const participantSID = this.activeRoom.localParticipant.sid
      let downlaodLink = await this.videoService.getDownloadLink(roomSID)
      console.log(downlaodLink)
      let downlaodMedia = await this.videoService.downlaodMedia(downlaodLink);
    }
  }
  fullScreen() {
    if (this.activeRoom) {

    }
  }
}
