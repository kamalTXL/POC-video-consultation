import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { CameraComponent } from './camera/camera.component';
import { VideoControlsComponent } from './video-controls/video-controls.component';
import { ParticipantsComponent } from './participants/participants.component';
import { HomeComponent } from './home/home.component';
import { SettingsComponent } from './settings/settings.component';
import { DeviceSelectComponent } from './settings/device-select.component';
import { RoomsComponent } from './rooms/rooms.component';
import { ChatComponent } from './chat/chat.component';
import { PreCallTestingComponent } from './Pre-call-testing/pre-call-testing/pre-call-testing.component';
import { PreCallHomeComponent } from './Pre-call-testing/pre-call-home/pre-call-home.component';
import { PreCallPreflightComponent } from './Pre-call-testing/pre-call-preflight/pre-call-preflight.component';
import { PreCallMediaconnectionComponent } from './Pre-call-testing/pre-call-mediaconnection/pre-call-mediaconnection.component';
import { PreCallAudioComponent } from './Pre-call-testing/pre-call-audio/pre-call-audio.component';
import { PreCallVideoComponent } from './Pre-call-testing/pre-call-video/pre-call-video.component';
import { PreCallBrowserSpportComponent } from './Pre-call-testing/pre-call-browser-spport/pre-call-browser-spport.component';
import { PreCallResultsComponent } from './Pre-call-testing/pre-call-results/pre-call-results.component';

@NgModule({
  declarations: [
    AppComponent,
    CameraComponent,
    VideoControlsComponent,
    ParticipantsComponent,
    HomeComponent,
    SettingsComponent,
    DeviceSelectComponent,
    RoomsComponent,
    ChatComponent,
    PreCallTestingComponent,
    PreCallHomeComponent,
    PreCallPreflightComponent,
    PreCallMediaconnectionComponent,
    PreCallAudioComponent,
    PreCallVideoComponent,
    PreCallBrowserSpportComponent,
    PreCallResultsComponent,
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'room/:name', component: HomeComponent, pathMatch: 'full' },
      { path: 'precall', component: PreCallHomeComponent, pathMatch: 'full' },
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
