﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Twilio;
using Twilio.AspNet.Core;
using Twilio.Jwt.AccessToken;
using Twilio.Rest.Api.V2010.Account;
using Twilio.TwiML;
using Twilio.TwiML.Voice;
using Twilio.Types;
using TwilioAudioConsultation.Abstrations;
using TwilioAudioConsultation.Options;

namespace TwilioAudioConsultation.Services
{
    public class AudioServices : IAudioServices
    {
        readonly TwilioSetting _twilioSettings;
        private static List<object> array = new List<object>();

        public AudioServices(Microsoft.Extensions.Options.IOptions<TwilioSetting> twilioOptions)
        {
            _twilioSettings = twilioOptions?.Value ?? throw new ArgumentNullException(nameof(twilioOptions));
            TwilioClient.Init(_twilioSettings.AccountSID, _twilioSettings.AuthToken);
        }

        public List<object> ListOfVoiceConsultation()
        {
            return array;
        }

        public TwiMLResult TwiMLForVoiceCall(HttpContext httpContext)
        {
            var twilioPhoneNumber = _twilioSettings.PhoneNumber;
            VoiceResponse voiceResponse = new();

            if (httpContext.Request.HasFormContentType)
            {
                var form = httpContext.Request.ReadFormAsync().Result;
                array.Add(form);
                var toPhoneNumber = form["To"].ToString();
                if (toPhoneNumber != twilioPhoneNumber)
                {
                    var dial = new Dial(callerId: twilioPhoneNumber);
                    dial.Number(toPhoneNumber);
                    voiceResponse.Append(dial);
                }
                else
                {
                    var caller = form["Caller"].ToString();
                    var dail = new Dial(callerId: caller);
                    dail.Client(twilioPhoneNumber);
                    voiceResponse.Append(dail);
                }

            }
            return Results.Extensions.TwiML(voiceResponse);
        }

        public string GenerateTokenForVoiceCall(string identity)
        {
            var grant = new VoiceGrant();
            grant.OutgoingApplicationSid = _twilioSettings.TwiMLAppId;
            grant.IncomingAllow = true;

            var grants = new HashSet<IGrant>
            {
                { grant }
            };

            var token = new Token(
                _twilioSettings.AccountSID,
                _twilioSettings.ApiKey,
                _twilioSettings.ApiSecret,
                identity,
                grants: grants).ToJwt();

            return token;
        }
    }
}
