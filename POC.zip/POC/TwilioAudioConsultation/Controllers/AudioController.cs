﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Twilio.AspNet.Core;
using Twilio.TwiML;
using Twilio.Types;
using TwilioAudioConsultation.Abstrations;

namespace TwilioAudioConsultation.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AudioController : ControllerBase
    {
        public readonly IAudioServices _audioService;
        public AudioController(IAudioServices audioService)
        {
            _audioService = audioService;
        }

        [HttpGet("list")]
        public IActionResult ListOfVoiceConsultation()
        {
            return new JsonResult(_audioService.ListOfVoiceConsultation());
        }

        [HttpPost]
        public TwiMLResult TwiMLForVoiceCallRequest()
        {
            var httpContext = HttpContext;
            return _audioService.TwiMLForVoiceCall(httpContext);
        }

        [HttpGet]
        public IActionResult GenerateToken(string identity)
        {
            return new JsonResult(_audioService.GenerateTokenForVoiceCall(identity));
        }

    }
}
