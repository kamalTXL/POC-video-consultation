import { Component, OnInit } from '@angular/core';
import { Call, Device } from '@twilio/voice-sdk';
import { AppService } from '../app.service';

@Component({
  selector: 'app-voice-call',
  templateUrl: './voice-call.component.html',
  styleUrls: ['./voice-call.component.css']
})
export class VoiceCallComponent implements OnInit {
  device!: Device;
  outgoingConnection!: Call;
  identity: string = "system";
  isMuted: boolean = false;

  constructor(private appService: AppService) { }


  ngOnInit(): void {
    this.appService.generateToken(this.identity).subscribe(token => {
      this.initializeVoiceCall(token);
    })
  }

  initializeVoiceCall(token: string) {
    // Setup Twilio.Device

    this.device = new Device(token, {
      allowIncomingWhileBusy: true,
      // Set Opus as our preferred codec. Opus generally performs better, requiring less bandwidth and
      // providing better audio quality in restrained network conditions. Opus will be default in 2.0.
      codecPreferences: [Call.Codec.Opus, Call.Codec.PCMU]
    });

    this.device.on("error", error => {
      console.log("Twilio.Device Error: " + error.message);
    });

  }

  async makeNewCall(number: string) {
    console.log(number);
    if(!number) return;
    if(!number.includes("+")) {
      number = "+"+number;
    }
    const deviceOptions: Device.ConnectOptions = {
      params: {
        To: number
      }
    }

    this.outgoingConnection = await this.device.connect(deviceOptions);
    
    this.outgoingConnection.on("ringing",() => {
      console.log("Ringing...");
    })
    this.outgoingConnection.on("closed", () => {
      console.log("Call Completed.")
    })
  }

  muteUserAudio() {
    this.outgoingConnection.mute(true);
    this.isMuted = true;
  }

  unMuteUserAudio() {
    this.outgoingConnection.mute(false);
    this.isMuted = false;
  }

  hangupCall() {
    // if (this.device) {
    //   this.device.disconnectAll();
    //   console.log('The call has ended.');
    // }
    if(this.outgoingConnection) {
      this.outgoingConnection.disconnect();
    }
  }
}
