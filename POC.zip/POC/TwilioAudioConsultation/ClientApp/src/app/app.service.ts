import { HttpClient, HttpParams } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) { 
    
  }

  generateToken(identity: string) {
    let params = new HttpParams().append("identity",identity);
    return this.http.get(this.baseUrl+"audio", {params})
    .pipe(map((response: any) => {
      return response;
    }));
  }
}
