﻿namespace TwilioAudioConsultation.Options
{
    public class TwilioSetting
    {
        public string AccountSID { get; set; }
        public string AuthToken { get; set; }
        public string ApiSecret { get; set; }
        public string ApiKey { get; set; }
        public string PhoneNumber { get; set; }
        public string TwiMLAppId { get; set; }
    }
}
