﻿using Twilio.AspNet.Core;

namespace TwilioAudioConsultation.Abstrations
{
    public interface IAudioServices
    {
        public List<object> ListOfVoiceConsultation();
        public TwiMLResult TwiMLForVoiceCall(HttpContext httpContext);
        public string GenerateTokenForVoiceCall(string identity);
    }
}
