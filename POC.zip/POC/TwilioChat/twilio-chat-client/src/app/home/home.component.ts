import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TwilioChatService } from '../services/twilio-chat.service';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  public userName: string = '';
  constructor(
    private activeRouter: Router,
    private twiliChatService: TwilioChatService,
    private formBuilder: FormBuilder
  ) {}
  ngOnInit() {
    localStorage.clear();
  }
  login(userName: string) {
    localStorage.setItem('userName', userName);
    this.twiliChatService.userLoginSuccess();
    this.activeRouter.navigate(['chat']);
  }
}
