import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TwilioChatService } from '../services/twilio-chat.service';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.scss'],
})
export class NavMenuComponent {
  isExpanded = false;
  isDarkMode: boolean = true;
  conversationName: string = '';
  public userLogged: boolean = false;
  constructor(
    private twilioChatService: TwilioChatService,
    private activeRouter: Router
  ) {}

  ngOnInit() {
    this.init();
  }

  init() {
    debugger;
    if (localStorage.getItem('userName')) {
      this.userLogged = true;
    } else {
      this.userLogged = false;
      this.activeRouter.navigate(['']);
    }
    this.twilioChatService.$isLogged.subscribe((res: any) => {
      this.userLogged = true;
    });
  }
  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
  logOut() {
    localStorage.removeItem('userName');
    this.twilioChatService.userLogout();
    this.init();
    this.activeRouter.navigate(['']);
  }
  // toggleTheme() {
  //   const active = this.themeService.getActiveTheme();
  //   if (active.name == 'light') {
  //     this.themeService.setTheme('dark');
  //     this.isDarkMode = true;
  //   } else {
  //     this.themeService.setTheme('light');
  //     this.isDarkMode = false;
  //   }
  // }

  async createConversation(conversationName: string) {
    debugger
    // this.twilioChatService.createConversation(conversationName);
    await this.twilioChatService.getOrCreateChannel(conversationName);
  }
}
