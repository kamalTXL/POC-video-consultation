// twilio-chat.service.ts
import { Inject, Injectable } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { Client as TwilioChatClient } from 'twilio-chat';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class TwilioChatService {
  private chatClient!: TwilioChatClient;
  corsURL = 'https://localhost:44358/';
  token: string = '';
  channelArray: any = [];

  $isLogged!: Observable<boolean>;

  private userLogged = new ReplaySubject<boolean>();

  constructor(
    private http: HttpClient // @Inject('BASE_URL') private baseUrl: string
  ) {
    this.$isLogged = this.userLogged.asObservable();
  }
  // message = [];

  getToken(serviceId: string, identity: string): Observable<any> {
    debugger;
    let params = new HttpParams()
      .append('serviceSID', serviceId)
      .append('identity', identity);
    console.log('url', this.corsURL);
    this.http
      .get<string>(this.corsURL + 'api/Chat/token', { params })
      .subscribe((res: string) => {
        this.token = res;
      });
    return this.http.get<string>(this.corsURL + 'api/Chat/token', { params });
  }

  getAllServices(): Observable<any> {
    return this.http.get<any>(this.corsURL + 'api/Chat/getAllServices');
  }

  async initializeChat(identity: string): Promise<void> {
    debugger;
    this.chatClient = await TwilioChatClient.create(this.token);
    console.log('chatClient', this.chatClient.getChannelByUniqueName);
  }

  async createChannel(channelName: string): Promise<void> {
    debugger;
    // Check if the channel already exists
    try {
      const existingChannel = await this.chatClient.getChannelByUniqueName(
        channelName
      );

      if (existingChannel) {
        console.log('Channel already exists');
        return;
      }
    } catch (ex: any) {
      // let mess = ex.message.toString()

      console.log('error', ex.message);
      // Create a new channel
      await this.chatClient?.createChannel({
        uniqueName: channelName,
      });

      console.log(`Channel ${channelName} created successfully`);
    }
  }

  async sendMessage(channelSid: string, messageBody: string): Promise<void> {
    debugger;
    const channel = await this.chatClient.getChannelBySid(channelSid);

    if (channel) {
      // Send a message to the channel
      await channel.sendMessage(messageBody);

      console.log('Message sent successfully');
    } else {
      console.error('Channel not found');
    }
    console.log('channel', channel);
  }

  async getAllChannels(): Promise<any> {
    debugger;
    // Get a list of all channels
    const channels = await this.chatClient?.getSubscribedChannels();
    let i = 0;
    this.channelArray = [];
    debugger;
    if (channels && channels.items) {
      channels.items.forEach((element: any) => {
        this.channelArray.push({
          sid: element.sid,
          friendlyName: element.channelState.friendlyName,
        });
      });
    }

    // console.log('All channels:', channels.items);
    return this.channelArray;
    // return channels;
  }

  private checkChatClient(): void {
    if (!this.chatClient) {
      throw new Error(
        'Twilio Chat client not initialized. Call initializeChat() first.'
      );
    }
  }

  async getAllChannelMessages(channelSid: string): Promise<any> {
    this.checkChatClient();

    const channel = await this.chatClient?.getChannelBySid(channelSid);
    debugger;
    if (channel) {
      // Retrieve all messages in the channel
      const messages = await channel.getMessages();
      console.log('All messages:', messages.items);
      return messages.items;
    } else {
      console.error('Channel not found');
      return [];
    }
  }

  public setChannelName(name: string = '') {
    localStorage.setItem('ChannelName', name);
  }
  public getChannelName() {
    return localStorage.getItem('ChannelName');
  }

  async userLogin(identity: string) {
    await this.getAllChannels();
    await this.getToken(this.channelArray[0], identity);
  }

  userLoginSuccess() {
    this.userLogged.next(true);
  }
  userLogout() {
    this.userLogged.next(false);
  }

  async getOrCreateChannel(channelName: string): Promise<any> {
    debugger;
    this.checkChatClient();

    // Check if the channel already exists
    let channel = await this.chatClient?.getChannelByUniqueName(channelName);
    debugger;
    // If the channel doesn't exist, create a new one
    if (!channel) {
      channel = await this.chatClient?.createChannel({
        uniqueName: channelName,
      });
      console.log('created');
    } else {
      console.log(`channel ${channelName} already exist`);
    }

    return channel;
  }
}
