// chat.component.ts
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TwilioChatService } from 'src/app/services/twilio-chat.service';
import { Conversation } from '@twilio/conversations';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
})
export class ChatComponent implements OnInit {
  messages: any[] = []; // Array to hold messages
  channelName: string = '';
  channelList: any[] = []; //array to hold all channel
  allChannel = [];
  inputBox: string = '';
  // token: string = '';
  identity: string = '';
  serviceId: any;
  channelSid: string = 'CH005cab0232774f80a9a6608847e2669c';
  conversationList: any;
  conversationListForSearch: any;
  selectedConversationSID: string = '';
  selectedConversation: Conversation | undefined;

  profileURL = '../assets/default.png'; //"https://therichpost.com/wp-content/uploads/2020/06/avatar2.png"
  fileImage = '../assets/fileImage.png';
  allConversations: Conversation[] = [];

  @ViewChild('MessageInput', { static: false }) messageInput!: ElementRef;
  @ViewChild('scrollMe', { static: true }) myScrollContainer!: ElementRef;

  constructor(
    private twilioChatService: TwilioChatService,
    private formBuilder: FormBuilder
  ) {
    this.identity = localStorage.getItem('userName') ?? '';
  }

  async ngOnInit(): Promise<void> {
    this.getToken();
    this.getConversationList();
  }

  getToken() {
    debugger;

    this.twilioChatService.getAllServices().subscribe((res: any) => {
      console.log('get allServices', res);
      if (res) this.serviceId = res[0];
      this.twilioChatService.getToken(res[0], this.identity).subscribe(() => {
        this.initalize();
      });
    });
  }

  async getConversationList() {
    this.channelList = await this.twilioChatService.getAllChannels();
    console.log('channel list', this.channelList);
  }

  async getChannelMessage() {
    this.messages = [];
    this.messages = await this.twilioChatService.getAllChannelMessages(
      this.selectedConversationSID
    );
    this.scrollToBottom();
    console.log('message', this.messages);
  }

  async initalize() {
    await this.twilioChatService.initializeChat(this.identity);
    this.getConversationList();
    this.getChannelMessage();
  }

  searchConversationList(searchValue: string = '') {
    debugger;
    this.conversationList = this.conversationListForSearch.filter((conv: any) =>
      conv.friendlyName.toUpperCase().includes(searchValue.toUpperCase())
    );
  }

  onSelectedConversation(conversation: Conversation) {
    debugger;
    this.selectedConversationSID = conversation.sid;
    if (this.channelList.length > 0) {
      debugger;
      this.selectedConversation = this.channelList.filter(
        (item: any) => item.sid == conversation.sid
      )[0];
      console.log(this.selectedConversation);
      this.getChannelMessage();
    }
  }
  async sendMessageToConveration(message: string) {
    debugger;
    if (this.selectedConversation) {
      await this.twilioChatService.sendMessage(
        this.selectedConversationSID,
        message
      );
      this.getChannelMessage();
      this.messageInput.nativeElement.value = null;
    }
  }

  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollTop =
        this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) {}
  }
}
