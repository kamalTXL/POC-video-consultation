﻿using System.Collections.Generic;
using Twilio.Rest.Conversations.V1.Conversation;

namespace SAAS_Twilio_Chat.Models
{
    public class ConversationDetails
    {
        public string FriendlyName { get; set; }
        public string ChatServiceId { get; set; }
        public string ChatId { get; set; }
        public List<ParticipantResource> Participants { get; set; }
    }
}
