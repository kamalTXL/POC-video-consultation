﻿namespace VideoCall.Options
{
    public class TwilioSetting
    {
        public string AccountSID { get; set; }
        public string ApiSecret { get; set; }
        public string ApiKey { get; set; }
        public string TwilioNumber { get; set; }
        public string AuthToken { get; set; }
    }
}
