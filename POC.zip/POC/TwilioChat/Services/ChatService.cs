﻿using Microsoft.Extensions.Options;
using SAAS_Twilio_Chat.Models;
using SASS_Twilio_SMS.Abstraction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Jwt.AccessToken;
using Twilio.Rest.Conversations.V1;
using Twilio.Rest.Conversations.V1.Conversation;
using VideoCall.Options;

namespace SASS_Twilio_SMS.Services
{
    public class ChatService : IChatService
    {
        readonly TwilioSetting _twilioSettings;

        public ChatService(IOptions<TwilioSetting> twilioOptions)
        {
            _twilioSettings = twilioOptions?.Value ?? throw new ArgumentNullException(nameof(twilioOptions));
            TwilioClient.Init(_twilioSettings.AccountSID, _twilioSettings.AuthToken);
            //TwilioClient.Init(_twilioSettings.ApiKey, _twilioSettings.ApiSecret);
        }

        public ConversationResource CreateConversation(string conversationName)
        {
            return ConversationResource.Create(friendlyName: conversationName);
        }

        public async Task<List<string>> GetServiceResource()
        {
            var services = await ServiceResource.ReadAsync();
            var requiredList = services.Select(service => service.Sid).ToList();
            return requiredList;
        }

        public async Task<IEnumerable<ConversationDetails>> GetAllConversation()
        {
            var conversationList = await ConversationResource.ReadAsync();
            var requiredList = conversationList.Select(conversation => GetAllConversationById(conversation, ParticipantResource.ReadAsync(conversation.Sid)));
            return await Task.WhenAll(requiredList);
            static async Task<ConversationDetails> GetAllConversationById(ConversationResource conversation, Task<Twilio.Base.ResourceSet<ParticipantResource>> participantTask)
            {
                var participants = await participantTask;
                return new ConversationDetails
                {
                    FriendlyName = conversation.FriendlyName,
                    ChatServiceId = conversation.ChatServiceSid,
                    ChatId = conversation.Sid,
                    Participants = participants.ToList()
                };
            }
        }


        public string FectchConversation(string conversationSID)
        {
            var conversation = ConversationResource.Fetch(pathSid: conversationSID);
            return conversation.ChatServiceSid;
        }
        public bool DeleteConversation(string conversationSID)
        {
            return ConversationResource.Delete(pathSid: conversationSID);
        }

        public string AddParticipantToConversationSMS(string conversationSID, string phNumber)
        {
            try
            {
                var participant = ParticipantResource.Create(
                messagingBindingAddress: "+" + phNumber,//"+919652860405", //" +918464007262",//"+17797720673",// + 919652860405",
                messagingBindingProxyAddress: _twilioSettings.TwilioNumber,//"+15185043525",//"+16204904749",
                pathConversationSid: conversationSID);
                return participant.Sid;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string AddParticipantToConversationChat(string conversationSID, string identity)
        {
            try
            {
                var participant = ParticipantResource.Create(
                identity: identity,
                pathConversationSid: conversationSID);
                return participant.Sid;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public string AddParticipantToConversationWhatsApp(string conversationSID, string phNumber)
        {
            try
            {
                var participant = ParticipantResource.Create(
                    messagingBindingAddress: "whatsapp:+" + phNumber,//"+919652860405", //" +918464007262",//"+17797720673",// + 919652860405",
                    messagingBindingProxyAddress: "whatsapp:+14155238886",//"+15185043525",//"+16204904749",
                    pathConversationSid: conversationSID);
                return participant.Sid;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string RemoveParticiPant(string conversationId, string participantId)
        {
            return ParticipantResource.Delete(new DeleteParticipantOptions(pathConversationSid: conversationId, pathSid: participantId)).ToString();
        }

        public string GetTwilioJwt(string serviceSID, string identity)
        {
            //string identity = Guid.NewGuid().ToString();
            var grant = new ChatGrant
            {
                ServiceSid = serviceSID

            };

            var grants = new HashSet<IGrant> {
                {
                    grant
                } };
            var token = new Token(
                        _twilioSettings.AccountSID,
                         _twilioSettings.ApiKey,
                         _twilioSettings.ApiSecret,
                         identity,
                         //nbf: DateTime.Now,
                         //expiration: DateTime.Now.AddMinutes(10),
                         //grants: new HashSet<IGrant> { grants }).ToJwt();
                         grants: grants).ToJwt();

            return token;
        }
    }

}
