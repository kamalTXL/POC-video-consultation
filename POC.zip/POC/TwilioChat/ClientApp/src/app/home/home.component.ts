import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../app.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  userName: string;
  constructor(private activeRouter: Router,private appService: AppService) {}
  ngOnInit() {
    localStorage.clear();
  }
  login(userName) {
    localStorage.setItem("userName",userName)
    this.appService.userLoginSuccess()
    this.activeRouter.navigate(['chat'])
  }
}
