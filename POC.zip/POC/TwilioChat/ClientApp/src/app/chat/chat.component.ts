import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { AppService } from "../app.service";
import * as $ from "jquery";
import { Client, Conversation, Media, Message } from "@twilio/conversations";
import { TheamService } from "../theam/theam.service";
import { Router } from "@angular/router";
declare var MediaRecorder: any;
@Component({
  selector: "app-chat",
  templateUrl: "./chat.component.html",
  styleUrls: ["./chat.component.scss"],
})
export class ChatComponent implements OnInit {
  @ViewChild("scrollMe", { static: true }) myScrollContainer: ElementRef;
  @ViewChild("MessageInput", { static: false }) messageInput: ElementRef;
  token = "";
  profileURL = "../assets/default.png"; //"https://therichpost.com/wp-content/uploads/2020/06/avatar2.png"
  fileImage = "../assets/fileImage.png";
  conversationList = [];
  typesOfConversation = [
    { id: 0, name: "Select Type" },
    { id: 1, name: "Add to Chat" },
    { id: 2, name: "Add to SMS" },
    { id: 3, name: "Add to WhatsApp" },
  ];
  conversationListForSearch = [];
  allConversations: Conversation[] = [];
  allMessages: Message[] = [];
  selectedConversationSID = "";
  identity: string = "";
  typeIdentity: string;
  selectedParticipantType: string = "0";
  typeParticipantTitle: string;
  serviceId: string;
  mediaRecorder; //: MediaRecorder
  isAudioRecordEnable: boolean = false;
  selectedConversation: Conversation = null;
  //window: any;
  allModifiedMessage = [];
  conversationsClient: Client;
  constructor(
    private appService: AppService,
    private themeService: TheamService,
    private activeRouter: Router
  ) {}

  ngOnInit() {
    $("#action_menu_btn").click(function () {
      $(".action_menu").toggle();
    });
    this.getToken();
    this.getConversationList();
    this.appService.$createConversation.subscribe((res) => {
      console.log("response", res);
      this.createConversation(res);
    });
  }

  ngDestroy() {
    if (this.conversationsClient) {
      localStorage.removeItem("userName");
      this.conversationsClient.shutdown();
    }
  }
  getToken() {
    // const serviceId = "IS6fd785fb59c24c6abdfa8cb1c23dde4e";
    this.identity = localStorage.getItem("userName");
    this.appService.getAllServices().subscribe((res) => {
      console.log(res);
      if (res) this.serviceId = res[0];
      this.appService.getToken(res[0], this.identity).subscribe((res) => {
        this.token = res;
        this.initConversation();
      });
    });
  }

  getConversationList() {
    this.appService.getConversationList().subscribe((res) => {
      console.log("conversation list", res);
      this.conversationList = res;
      this.conversationListForSearch = res;
    });
  }
  initConversation = async () => {
    window["conversationsClient"] = Client;
    console.log("token", this.token);
    this.conversationsClient = new Client(this.token);
    // console.log("conversation list", this.conversationList);
    this.conversationsClient.on("connectionStateChanged", (state) => {
      console.log(`State ${state}`);

      // if (state == "connecting") {
      //   console.log("State connecting");
      // }
      // if (state == "connected") {
      //   console.log("State connected");
      // }
      // if (state == "disconnecting") {
      //   console.log("State disconnecting");
      //   // this.appService.getToken(this.serviceId, this.identity).subscribe(res => {
      //   //   this.token = res;
      //   //   this.conversationsClient.updateToken(res)
      //   // });
      // }
      // if (state == "disconnected") {
      //   console.log("State disconnected");
      //   this.activeRouter.navigate([""]);
      // }
      // if (state == "denied") {
      //   console.log("State denied");
      // }
    });

    this.conversationsClient.on("conversationAdded", (conversation) => {
      console.log("Conversation Added", conversation);
      this.allConversations.push(conversation);
      //conversation.add("212124424")
    });
    // this.conversationsClient.onWithReplay
    this.conversationsClient.on("conversationJoined", (conversation) => {
      console.log("Conversation Joined", conversation);
    });

    this.conversationsClient.on("conversationUpdated", (conversation) => {
      console.log("conversation Updated", conversation);
      this.getAllMessages();
    });
    this.conversationsClient.on("conversationLeft", (conversationLeft) => {
      console.log("Conversation Left", conversationLeft);
      this.allConversations = this.allConversations.filter(
        (conversation) => conversation.sid != conversationLeft.sid
      );
    });

    this.conversationsClient.on("participantJoined", (participant) => {
      console.log("Participant Joined", participant);
    });

    this.conversationsClient.on("participantLeft", (participant) => {
      console.log("Participant Left", participant);
    });
    this.conversationsClient.on("messageAdded", (message) => {
      console.log("New Message Added", message);
      this.scrollToBottom();
    });
  };

  onSelectedConversation(conversation: Conversation) {
    debugger
    this.selectedConversationSID = conversation.sid;
    this.allMessages = [];
    this.selectedConversation = this.allConversations.filter(
      (item) => item.sid == conversation.sid
    )[0];
    this.getAllMessages();
  }

  searchConversationList(searchValue) {
    this.conversationList = this.conversationListForSearch.filter((conv) =>
      conv.friendlyName.toUpperCase().includes(searchValue.toUpperCase())
    );
    // if (this.conversationList.length == 0) {
    //   this.createConversation(searchValue)
    // }
  }

  sendMessageToConveration(message) {
    if (this.selectedConversation)
      this.selectedConversation.sendMessage(message);
    this.messageInput.nativeElement.value = null;
  }

  createConversation(conversationName) {
    console.log("conversations Client", this.conversationsClient);
    if (this.conversationsClient)
      this.conversationsClient
        .createConversation({ friendlyName: conversationName })
        .then((res) => {
          console.log("create conversation", res);
          this.getConversationList();
        });
  }

  getAllMessages() {
    debugger
    if (this.selectedConversation) {
      this.selectedConversation.getMessages().then(
        (res) => {
          this.allMessages = res.items;
          this.scrollToBottom();
        },
        (err) => {
          alert("Participant not available in this conversation");
        }
      );
    }
  }

  deleteConversation(conversationSID = this.selectedConversationSID) {
    this.appService.deleteConversation(conversationSID).subscribe((res) => {
      this.getConversationList();
    });
  }

  selectedImage(event) {
    console.log(event);
    if (event.target.files[0].size > 250000) {
      alert("File Size should be less than 250KB");
      return;
    }
    const formData = new FormData();
    let file = event.target.files[0];
    formData.append("file1", file);
    if (this.selectedConversation)
      this.selectedConversation.sendMessage(formData);
  }

  // remove after work
  fileRender(files: Media[]) {
    files[0].getContentTemporaryUrl().then((url) => {
      console.log(url);
    });
  }
  getMessageData(message: Message) {
    if (message.type == "text") {
      return message.body;
    }
    if (message.type == "media") {
      this.fileRender(message.attachedMedia);
    }
  }

  async getMedia(message: Media) {
    return await message.getContentTemporaryUrl();
  }

  startRecord() {
    navigator.mediaDevices
      .getUserMedia({ audio: true, video: false })
      .then(this.handleSuccess);
  }

  handleSuccess = (stream) => {
    const options = { mimeType: "audio/ogg" };
    const recordedChunks = [];
    this.mediaRecorder = new MediaRecorder(stream);

    this.mediaRecorder.addEventListener("dataavailable", function (e) {
      if (e.data.size > 0) recordedChunks.push(e.data);
    });
    console.log(this.mediaRecorder.mimeType);
    this.mediaRecorder.addEventListener("stop", () => {
      let record = new Blob(recordedChunks, { type: "audio/mpeg" });
      const formData = new FormData();
      formData.append("file1", record);
      if (this.selectedConversation)
        this.selectedConversation.sendMessage(formData);
    });

    this.mediaRecorder.start();
    this.isAudioRecordEnable = true;
  };
  stopRecord() {
    this.mediaRecorder.stop();
    this.isAudioRecordEnable = false;
  }

  toggleTheme() {
    const active = this.themeService.getActiveTheme();
    if (active.name == "light") {
      this.themeService.setTheme("dark");
    } else {
      this.themeService.setTheme("light");
    }
  }

  selectedConversationType(type) {
    console.log(type);
    this.selectedParticipantType = type;
    if (type == "1") {
      this.typeParticipantTitle = "User Name";
    } else {
      this.typeParticipantTitle = "Phone Number";
    }
  }

  addParticipant(typeIdentity) {
    debugger
    console.log(typeIdentity);
    console.log(this.selectedConversationSID);
    if (
      this.selectedConversationSID &&
      typeIdentity &&
      this.selectedParticipantType != "0"
    ) {
      this.appService
        .addParticipantToConversation(
          this.selectedParticipantType,
          this.selectedConversationSID,
          typeIdentity
        )
        .subscribe((res) => {
          console.log(res);
        });
    }
  }

  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollTop =
        this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) {}
  }

  downloadFile() {
    // Construct the <a> element
    // var link = document.createElement("a");
    // link.download = "testFIle.ex";
    // // Construct the uri
    // //var uri = 'data:text/csv;charset=utf-8;base64,' + someb64data
    // link.href = uri;
    // document.body.appendChild(link);
    // link.click();
    // // Cleanup the DOM
    // document.body.removeChild(link);
  }
}
