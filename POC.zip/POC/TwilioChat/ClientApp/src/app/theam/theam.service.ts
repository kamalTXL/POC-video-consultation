import { EventEmitter, Inject, Injectable } from '@angular/core';
import { ACTIVE_THEME, Theme, THEMES } from './theam-models';

@Injectable()
export class TheamService {
  themeChange = new EventEmitter<Theme>();
  constructor(@Inject(THEMES) public themes: Theme[], @Inject(ACTIVE_THEME) public theme:string) { }
  
  getActiveTheme() {
    const theme = this.themes.find(t => t.name === this.theme);
    if(!theme) {
      console.error("Theme Not found:",theme)
    }
    return theme;
  }

  setTheme(name: string) {
    this.theme = name;
    this.themeChange.emit(this.getActiveTheme());
  }
}
