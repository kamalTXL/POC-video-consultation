import { Theme } from "./theam-models";

export const darkTheme: Theme = {
    name: "dark",
    properties: {
        '--color': '#fff',
        '--black': '0 ,0 ,0',
        '--white': '255,255,255',
        '--button': '0.3',


    }
}

// properties: {
//     '--background': '#1F2125'
// },