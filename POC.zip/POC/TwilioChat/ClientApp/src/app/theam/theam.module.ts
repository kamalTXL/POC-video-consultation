import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TheamDirective } from './theam.directive';
import { ACTIVE_THEME, ThemeOptions, THEMES } from './theam-models';
import { ModuleWithProviders } from '@angular/core';
import { TheamService } from './theam.service';



@NgModule({
  declarations: [TheamDirective],
  imports: [CommonModule],
  providers: [TheamService],
  exports: [TheamDirective]
})
export class TheamModule { 
  static forRoot(options: ThemeOptions): ModuleWithProviders {
    return {
      ngModule: TheamModule,
      providers: [
        {
          provide: THEMES,
          useValue: options.themes
        },
        {
          provide: ACTIVE_THEME,
          useValue: options.active
        }
      ]
    }
  }
}
