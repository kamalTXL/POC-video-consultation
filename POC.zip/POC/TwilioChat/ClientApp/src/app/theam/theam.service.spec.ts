import { TestBed } from '@angular/core/testing';

import { TheamService } from './theam.service';

describe('TheamService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TheamService = TestBed.get(TheamService);
    expect(service).toBeTruthy();
  });
});
