import { Theme } from "./theam-models";

export const lightTheme: Theme = {
    name: "light",
    properties: {
        '--color': '#000',
        '--black': '255,255,255,',
        '--white': '0,0,0',
        '--button': '0.7',

    }
}