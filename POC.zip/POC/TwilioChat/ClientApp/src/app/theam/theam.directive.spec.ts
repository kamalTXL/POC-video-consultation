import { TheamDirective } from './theam.directive';

describe('TheamDirective', () => {
  it('should create an instance', () => {
    const directive = new TheamDirective();
    expect(directive).toBeTruthy();
  });
});
