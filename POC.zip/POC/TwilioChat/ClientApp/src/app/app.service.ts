import { HttpClient, HttpParams } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { Observable, ReplaySubject, Subject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class AppService {
  corsURL = "https://localhost:44358/";

  $createConversation: Observable<string>;
  $isLogged: Observable<boolean>;
  private updateConversation = new ReplaySubject<string>();
  private userLogged = new ReplaySubject<boolean>();

  constructor(
    private http: HttpClient,
    @Inject("BASE_URL") private baseUrl: string
  ) {
    this.$createConversation = this.updateConversation.asObservable();
    this.$isLogged = this.userLogged.asObservable();
  }

  getToken(serviceId, identity): Observable<any> {
    debugger
    let params = new HttpParams()
      .append("serviceSID", serviceId)
      .append("identity", identity);
    console.log("url", this.baseUrl);
    return this.http.get<string>(this.baseUrl + "api/Chat/token", { params });
  }

  getAllServices(): Observable<any> {
    return this.http.get<any>(this.baseUrl + "api/Chat/getAllServices");
  }

  getConversationList(): Observable<any> {
    return this.http.get<any>(this.baseUrl + "api/Chat");
  }

  deleteConversation(conversationSID) {
    let params = new HttpParams().append("conversationSID", conversationSID);
    return this.http.delete(this.baseUrl + "api/Chat/deleteConversation", {
      params,
    });
  }

  addParticipantToConversation(
    participantType,
    conversationSID,
    participantIdentity
  ) {
    debugger;
    let apiType;
    let params = new HttpParams().append("conversationSID", conversationSID);
    if (participantType == "1") {
      apiType = "addParticipantChat";
      params = params.append("identity", participantIdentity);
    } else if (participantType == "2") {
      apiType = "addParticipantSMS";
      params = params.append("phoneNumber", participantIdentity);
    } else if (participantType == "3") {
      apiType = "addParticipantWhatsApp";
      params = params.append("phoneNumber", participantIdentity);
    } else {
      return;
    }
    let url = `${this.baseUrl}api/Chat/${apiType}`;
    console.log("url", url);
    console.log("param", params);
    return this.http.get<string>(`${this.baseUrl}api/Chat/${apiType}`, {
      params,
    });
  }
  createConversation(conversationName) {
    if (conversationName) this.updateConversation.next(conversationName);
  }
  userLoginSuccess() {
    this.userLogged.next(true);
  }
}
