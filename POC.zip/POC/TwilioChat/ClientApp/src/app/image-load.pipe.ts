import { Pipe, PipeTransform } from '@angular/core';
import { Message } from '@twilio/conversations';

@Pipe({
  name: 'imageLoad'
})
export class ImageLoadPipe implements PipeTransform {

  async transform(value: Message, ...args: any[]): Promise<any> {
    let url = await value.attachedMedia[0].getContentTemporaryUrl()
    console.log(url)
    return url;
  }

}
