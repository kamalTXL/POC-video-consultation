import { ImageLoadPipe } from './image-load.pipe';

describe('ImageLoadPipe', () => {
  it('create an instance', () => {
    const pipe = new ImageLoadPipe();
    expect(pipe).toBeTruthy();
  });
});
