import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { TheamService } from '../theam/theam.service';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.scss']
})
export class NavMenuComponent {
  isExpanded = false;
  isDarkMode: boolean = true;
  conversationName: string;
  userLogged: boolean = false;
  constructor( private themeService: TheamService, private appSevice: AppService, private activeRouter: Router) { }

  ngOnInit() {
    if(localStorage.getItem("userName")) {
      this.userLogged = true;
    } else {
      this.activeRouter.navigate([''])
    }
    this.appSevice.$isLogged.subscribe(res => {
      this.userLogged = true;
    })
  }
  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
  logOut() {
    localStorage.removeItem("userName")
  }
  toggleTheme() {
    const active = this.themeService.getActiveTheme();
      if(active.name == "light") {
        this.themeService.setTheme('dark')
        this.isDarkMode = true;
      } else {
        this.themeService.setTheme('light')
        this.isDarkMode = false;
      }
    }

    createConversation(conversationName) {
      this.appSevice.createConversation(conversationName)
    }
}
