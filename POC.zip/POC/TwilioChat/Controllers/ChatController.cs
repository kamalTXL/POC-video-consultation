﻿using Microsoft.AspNetCore.Mvc;
using SASS_Twilio_SMS.Abstraction;
using System.Threading.Tasks;

namespace SAAS_Twilio_Chat.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChatController : ControllerBase
    {
        private readonly IChatService _chatService;
        public ChatController(IChatService smsService)
        {
            _chatService = smsService;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllConversation()
        {
            var conversationList = _chatService.GetAllConversation();
            return new JsonResult(await conversationList);
        }
        [HttpPost("create")]
        public IActionResult CreateConversation(string conversationName)
        {
            var conversation = _chatService.CreateConversation(conversationName);
            return Ok(conversation);
        }

        [HttpGet("getServiceSID")]
        public IActionResult FetchConversation(string conversationSID)
        {
            var conversationServiceSID = _chatService.FectchConversation(conversationSID);
            return Ok(conversationServiceSID);
        }

        [HttpDelete("deleteConversation")]
        public IActionResult DeleteConversation(string conversationSID)
        {
            _chatService.DeleteConversation(conversationSID);
            return Ok();
        }

        [HttpGet("addParticipantSMS")]
        public IActionResult AddParticipantToConversationSMS(string conversationSID, string phoneNumber)
        {
            return new JsonResult(_chatService.AddParticipantToConversationSMS(conversationSID, phoneNumber));
        }


        [HttpGet("addParticipantWhatsApp")]
        public IActionResult AddParticipantToConversationWhatsApp(string conversationSID, string phoneNumber)
        {
            return new JsonResult(_chatService.AddParticipantToConversationWhatsApp(conversationSID, phoneNumber));
        }
        [HttpGet("addParticipantChat")]
        public IActionResult AddParticipantToConversationChat(string conversationSID, string identity)
        {
            return new JsonResult(_chatService.AddParticipantToConversationChat(conversationSID, identity));
        }
        [HttpDelete("removeParticipant")]
        public IActionResult RemoveConversation(string conversationSID, string participantId)
        {
            return new JsonResult(_chatService.RemoveParticiPant(conversationSID, participantId));
        }
        [HttpGet("token")]
        public IActionResult GenerateToken(string serviceSID, string identity)
        {
            return new JsonResult(_chatService.GetTwilioJwt(serviceSID, identity));
        }

        [HttpGet("getAllServices")]
        public async Task<IActionResult> GetAllServices()
        {
            var services = _chatService.GetServiceResource();
            return new JsonResult(await services);
        }
    }
}
