﻿using SAAS_Twilio_Chat.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Twilio.Rest.Conversations.V1;

namespace SASS_Twilio_SMS.Abstraction
{
    public interface IChatService
    {
        public ConversationResource CreateConversation(string conversationName);
        public Task<List<string>> GetServiceResource();
        public Task<IEnumerable<ConversationDetails>> GetAllConversation();
        public string FectchConversation(string conversationSID);
        public bool DeleteConversation(string conversationSID);
        public string AddParticipantToConversationSMS(string conversationSID, string phNumber);
        public string AddParticipantToConversationChat(string conversationSID, string identity);
        public string AddParticipantToConversationWhatsApp(string conversationSID, string phNumber);
        public string RemoveParticiPant(string conversationId, string participantId);
        public string GetTwilioJwt(string serviceSID, string identity);
    }
}
